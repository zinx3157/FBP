LABELONZEWAY 1.2.1 — POS80C HOSTED PRINT GATEWAY
=================================================

PURPOSE
- Lets the public SHIPDESK and LabelOnZeWay GitHub Pages apps send direct
  ESC/POS print jobs through this computer to a private-network POS80C.
- Includes the LabelOnZeWay 1.2.1 APK-style iPhone/iPad web app for dependable
  local direct printing.
- Normal browser, AirPrint, and Android system printing do not need this gateway.

PRECONFIGURED PUBLIC SITE
  https://zinx3157.github.io/FBP/

REQUIREMENTS
- Python 3 on the Mac or Windows PC.
- The computer must reach the POS80C private IP on TCP port 9100.
- For phone use, both devices must be on the same Wi-Fi/LAN and the firewall
  must allow inbound TCP port 8765 on private networks.

START — macOS
1. Extract this entire ZIP. Do not run a launcher from inside the ZIP preview.
2. Double-click Start_Hosted_POS80C_Gateway.command.
3. If macOS blocks it, Control-click/right-click it, choose Open, and confirm.
4. Keep Terminal open while printing.

START — Windows
1. Extract this entire ZIP.
2. Double-click Start_Hosted_POS80C_Gateway.bat.
3. Allow Python through Windows Firewall for private networks if prompted.
4. Keep the window open while printing.

APP SETTINGS
- SHIPDESK on this computer: http://127.0.0.1:8765
- Printer IP: the POS80C private-network IP, currently 192.168.100.173 if unchanged
- Printer port: 9100 unless configured differently

IPHONE / IPAD DIRECT PRINT
Safari cannot open the POS80C raw TCP port and does not reliably allow the
public HTTPS app to call an HTTP LAN gateway. Use the local LabelOnZeWay URL
shown by the gateway, for example:

  http://COMPUTER_LAN_IP:8765/labelonzeway/

In LabelOnZeWay Settings choose Direct ESC/POS · local Wi-Fi gateway, keep the
gateway URL on auto, enter the printer IP and port, then run TEST GATEWAY and
PRINT + CUT TEST. The direct job uses no added feed by default and cuts after
every physical label copy.

IPHONE / IPAD SYSTEM PRINT
The public app remains available at:

  https://zinx3157.github.io/FBP/labelonzeway/

Use iPhone / iPad system print · AirPrint there. In Safari, use Share > Add to
Home Screen for the standalone APK-style layout.

SECURITY
- Hosted requests allow only the configured origin https://zinx3157.github.io.
- Printer targets are restricted to private, link-local, or loopback addresses.
- No GitHub password or token is requested or stored.
- To use a different GitHub Pages site later, run: python3 configure_gateway.py

MANUAL START
  python3 hosted_pos80c_gateway.py

Stop with Control-C.
