# LabelOnZeWay Android Native 1.3.1 — Validation Results

Validation date: 2026-08-15

## Passed

### Address-book recovery and export

- **Deep Rescue** and **Export CSV** are present in the customer toolbar and Address Book.
- Deep Rescue scans all readable localStorage values with bounded recursion and recovers nested address books, manifests, archives, retained label copies, cloud queues, and legacy customer/recipient structures.
- Current customers are retained; conservative matching can enrich blank fields without deleting legacy source data.
- Focused coverage passed with five nested source classes, source/count preview, cancellation, setting exclusions, source immutability, conservative merge, destination persistence, and automatic rescue CSV.
- The final APK contains the recovery/export interface, cloud client, configuration, and updated service worker.

### Complete Android workflows

All five retained Android JavaScript suites plus the dedicated Deep Rescue suite passed after final Capacitor synchronization:

- native direct-print contract;
- compact mobile customer/label workflow;
- navigation, discovery, fallback, and deferred queue;
- reported mobile layout/copies/profile fixes;
- retained complete workflow/action coverage.

Validated behavior includes New Label, Batch Delete Label, item quantity vs. copies 1–20, centered Manifest, Back/Cancel, company-profile creation, archives, reports, backups, system printing, and direct printing.

### POS80C print contract

- A simulated two-label job produced 2 raster commands, 2 partial cuts, and 0 added-feed commands.
- A simulated label with 3 copies produced 3 rasters, 3 cuts, and 0 added-feed commands.
- Bounded cancellable local-network discovery, Android system-print fallback, and device-local deferred queues passed.

### Capacitor and Android build

- Capacitor Android copy/sync completed and preserved `MainActivity.java` and `POS80PrinterPlugin.java` byte-for-byte.
- JDK 21.0.12, Gradle 8.11.1, and Android SDK 35 were used.
- `assembleDebug` completed successfully.
- `lintDebug` completed successfully with 0 errors and 28 non-blocking warnings.
- Warning review: 12 duplicate day/night splash-resource notices, 8 generated/Capacitor resource-usage notices, 3 available AndroidX updates, 2 missing monochrome-icon notices, 2 splash density-size notices, and 1 densityless splash-location notice. No correctness, security, permission, API, or printing error was reported; no automatic dependency/resource rewrite was applied.

### Dependency audit

- Full npm development-tool audit: 9 transitive findings (2 moderate, 6 high, 1 critical), reached through the Capacitor asset/build toolchain (`tar`, `sharp`, `minimatch`, `uuid`, and related tooling).
- Production/runtime audit (`npm audit --omit=dev`): **0 findings**.
- No breaking `npm audit fix --force` was applied. Reassess the development tools when compatible upstream Capacitor/asset updates are available.

### APK metadata and update compatibility

- Package: `mg.labelonzeway.app`
- Version: `1.3.1`
- Version code: `6`
- Minimum SDK: `23`
- Target/compile SDK: `35`
- APK size: `4,671,092` bytes
- APK SHA-256: `ca89afcfccb80dc3c2796e780394f6d1f56b1168980a04eac06a3bddfb1337ab`
- Signer certificate SHA-256: `3b6575bfc0cb9cdcb7e57594ed6c52fe64d003619e7abcefd645efbb4a98bc1e`
- Android v1 and v2 signature verification passed.
- The signer matches v1.2.1, supporting an in-place debug update.
- Synchronized `www/index.html` SHA-256: `069911666758dc273a3984ec643ad3338fd2e6c07864b237ac8d153b09efe0f1`
- Synchronized native bridge SHA-256: `490bd7c88a676fd75add9ba9014b3ff843c29c18a654a0b72cb9e88ed670170c`

## Physical regression still required

The earlier Android build passed a real POS80C test. The v1.3.1 APK still requires final physical verification of:

- in-place update and data retention;
- customer recovery/export behavior with real device storage;
- printer auto-detection on the actual LAN/hotspot;
- no avoidable gap and one cut after every label copy;
- system-print fallback and deferred queue retry;
- shared-workspace synchronization using authorized staff accounts.

Do not uninstall the old APK or clear app data before backups and exports are verified.
