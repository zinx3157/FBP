# LabelOnZeWay Android v1.2.1

**Status: pre-release — physical POS80C regression required**

This Android update addresses the four reported phone issues while preserving the complete LabelOnZeWay/SHIPDESK workflow and the direct network POS80C print path.

## Fixed

- Reorganized the Batch Labels area into readable, ordered mobile controls.
- Added **Label copies to print** as a separate value from item quantity.
- Preserved copy count in saved parcels, Manifest rows, reprints, selected-label printing, deferred jobs, backup/restore, and CSV export.
- Direct and Android system printing now expand each logical label to its requested number of physical copies.
- Centered and constrained Manifest/Batch content on phone screens.
- Added company-profile creation directly in **Settings → Company Profiles**.

## Preserved

- Contextual Back and Cancel controls plus Android hardware-back handling
- Compact phone navigation and print menus
- Direct raw-TCP ESC/POS printing over LAN, printer Wi-Fi, or phone hotspot
- Automatic private-network POS80C discovery on port `9100`
- Android system-print fallback and per-profile deferred print queues
- Compact 576-dot output, zero added feed by default, and one partial cut per physical copy
- Customers, parcels, Manifest, payments, batch labels, reports, reconciliation, archive, backup/restore, and profiles

## Validation

- All five JavaScript regression suites pass.
- Android `assembleDebug` passes with JDK 21, SDK 35, and Gradle 8.11.1.
- Android `lintDebug` passes with 0 errors and 28 non-blocking warnings.
- APK metadata: package `mg.labelonzeway.app`, version `1.2.1`, version code `4`, minimum SDK 23, target SDK 35.
- Signature matches the accepted prior Android builds for in-place updates.

## Downloads

- `LabelOnZeWay-Android-v1.2.1-debug.apk`
  - SHA-256: `245e9fbeae8a87fb1a75e04ed257e949a702caaf95046201d0e0d77db677854b`
- `LabelOnZeWay_Android_Native_v1.2.1.zip`
  - SHA-256 is supplied alongside the final source archive.

## Physical test required

Before promoting this build beyond pre-release, confirm on the real POS80C:

1. A parcel with item quantity `4` and label copies `3` remains logically one parcel but prints exactly three labels.
2. The three copies print consecutively with no blank feed.
3. The printer cuts once after every physical copy.
4. Selected Manifest parcels honor each saved copy count.
5. Auto-detection, deferred retry, and Android system printing still work.
6. Batch, Manifest, Back/Cancel, and company-profile creation display correctly on the phone.

See `README.md` for the full test procedure.
