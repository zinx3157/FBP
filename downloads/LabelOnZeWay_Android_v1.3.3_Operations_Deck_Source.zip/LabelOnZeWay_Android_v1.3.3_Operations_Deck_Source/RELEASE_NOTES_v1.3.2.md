# LabelOnZeWay Android v1.3.2 — Claims Vault & Shared Sync

## Added

- Permanent, versioned electronic copy of every generated label in **Label Claims Vault**.
- Search, preview, and one-copy claim reprint independent of the physical 1–20 copies setting.
- Claim copies survive ordinary Manifest/archive removal, have no automatic expiry, and are included in backup/restore.
- Shared `label_copy` synchronization across LabelOnZeWay and SHIPDESK for authorized staff in the same Supabase workspace/profile.
- Pull-before-push reconciliation, explicit deletion tombstones, and protection against accidental customer mass deletion when a local address book is unexpectedly empty.

## Preserved

- Direct TCP ESC/POS POS80C printing, automatic printer detection, system printing, cut after each label, and no extra inter-label feed.
- Full parcel/customer/Manifest/archive/payment/report workflow.
- Device-local printer settings and active/deferred print queues.
- Deep Rescue and non-destructive address-book CSV export.

## Upgrade safety

Install `LabelOnZeWay_Android_v1.3.2_ClaimsSync.apk` **over** the existing app. Do not uninstall first: uninstalling deletes device-local app storage. Export the address book and download a full backup before updating.

Existing Supabase projects must run `SUPABASE_CLAIMS_MIGRATION.sql` (or rerun the full current `SUPABASE_SETUP.sql`) before synchronized claim copies can upload.
