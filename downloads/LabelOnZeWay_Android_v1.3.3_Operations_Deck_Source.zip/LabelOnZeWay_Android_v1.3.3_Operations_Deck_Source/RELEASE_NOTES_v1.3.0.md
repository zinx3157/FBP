# LabelOnZeWay Android v1.3.0

Date: 2026-08-15

## Added

- Non-destructive **Recover Old Books** with source discovery, preview/confirmation, conservative deduplication, and missing-field enrichment.
- Direct **Export CSV** for the current address book.
- Supabase shared-workspace synchronization for authorized business records.
- Forgot Password, Set New Password, and signed-in Change Password flows.

## Retained

- Complete New Label, Batch, Manifest, archive, report, backup, and company-profile workflows.
- Separate item quantity and physical label copies (1–20).
- Batch Delete Label, New Label, Back, Cancel, compact mobile layouts, and centered Manifest.
- Direct raw-TCP POS80C printing, bounded cancellable automatic discovery, Android system printing, zero added feed by default, and one cut after every label copy.
- Printer settings and active/deferred queues remain device-local.

## Package

- App ID: `mg.labelonzeway.app`
- Version: `1.3.0`
- Version code: `5`
- Minimum SDK: `23`
- Target/compile SDK: `35`
- APK: `LabelOnZeWay-Android-v1.3.0-debug.apk`
- APK SHA-256: `875305395e63cff29be3c9f4ddf4500463060e3cfa19fe80fd5247f374a515ed`

The APK uses the same debug certificate as v1.2.1, allowing an in-place test update. Back up first and do not uninstall the older app before confirming data retention.

## Validation

- Complete five-suite Android JavaScript regression run passed.
- Capacitor Android sync completed and preserved the custom native printer bridge.
- Gradle `assembleDebug` completed successfully with JDK 21.
- APK metadata, embedded recovery/export/cloud assets, and signature continuity were verified.

Physical Android regression testing of v1.3.0 remains required even though the earlier direct POS80C build passed.
