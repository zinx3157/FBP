# LabelOnZeWay Android v1.3.1 — recovery update

Date: 2026-08-15

- Adds bounded, non-destructive **Deep Rescue** across nested localStorage structures, with source/count preview and automatic rescue CSV.
- Preserves current customers and tested historical source values while conservatively deduplicating/enriching.
- Prevents an unexpectedly empty local customer book from creating non-forced mass cloud tombstones; explicit deletion still synchronizes.
- Retains direct POS80C printing, automatic discovery, Android system print, compact New/Batch/Manifest workflows, copies, Back/Cancel, archives, reports, profiles, and cloud synchronization.

## Update metadata

- Package: `mg.labelonzeway.app`
- Version: `1.3.1`
- Version code: `6`
- APK: `LabelOnZeWay_Android_v1.3.1_Recovery.apk`
- SHA-256: `ca89afcfccb80dc3c2796e780394f6d1f56b1168980a04eac06a3bddfb1337ab`
- Signer certificate SHA-256: `3b6575bfc0cb9cdcb7e57594ed6c52fe64d003619e7abcefd645efbb4a98bc1e`

**Install this APK over the existing app. Do not uninstall first.** An uninstall removes isolated native app data that Deep Rescue may be able to recover.

Automated workflows, dedicated Deep Rescue coverage, APK assembly, APK signature/version checks, and Android lint (0 errors) pass. Physical in-place update, recovery, cloud, and POS80C regression testing remain required on the affected phone.
