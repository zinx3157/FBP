import { Capacitor, registerPlugin } from '@capacitor/core';

const POS80Printer = registerPlugin('POS80Printer');
window.LabelOnZeWayNative = {
  isNative: Capacitor.isNativePlatform(),
  platform: Capacitor.getPlatform(),
  printer: POS80Printer
};
window.dispatchEvent(new CustomEvent('labelonzeway-native-ready'));
