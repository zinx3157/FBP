# LabelOnZeWay Android Native 1.3.3

Native Android application for the complete LabelOnZeWay workflow, including direct ESC/POS printing from the phone to a network POS80C without a Mac, browser gateway, or third-party print utility during normal printing.

## Version 1.3.3 update

Version 1.3.3 applies Google Stitch Proposal A — Operations Deck across the native mobile workflow. It adds Home and More destinations, a live dispatch dashboard, compact control center, exact selected-label deletion for Batch and Manifest, and safer Claims Vault-retaining confirmations while preserving the direct POS80C, system print, cloud, offline, reports, address-book, and backup implementations.

This release retains the accepted POS80C output and complete mobile workflow while adding historical address-book recovery, CSV export, cloud synchronization, secure password flows, and the earlier Android phone fixes:

- Reorganized **Batch Labels** into ordered, phone-safe controls with explicit field labels and readable Scan, Print, Manifest, and Remove actions
- Added **Label copies to print** as a separate value from item quantity in New Label, Batch, saved Manifest, selected-label, reprint, direct ESC/POS, system-print fallback, and deferred-queue workflows
- Direct printing emits one compact raster and one cut per physical copy, with zero added feed between copies by default
- Constrained and centered the Manifest and Batch views so they cannot push the phone layout sideways
- Added an in-Settings **Company Profiles** form that creates and switches profiles without relying on a hidden mobile header button or JavaScript prompt
- Preserved contextual **Back** and **Cancel**, Android hardware back, compact print menus, automatic printer detection, Android system printing, and per-profile deferred queues
- Customers, parcels, manifest, payments, batch labels, reports, reconciliation, archive, backup/restore, profiles, system printing, and direct POS80C printing remain available
- Added non-destructive **Deep Rescue** across nested address books, manifests, archives, saved labels, cloud queues, and legacy recipient/customer structures, with source/count preview and automatic rescue CSV
- Added secure Supabase shared-workspace synchronization and Forgot/Set/Change Password flows; printer settings and active queues stay device-local
- Added the permanent, versioned **Label Claims Vault** with search, preview, one-copy reprint, backup/restore, and SHIPDESK/LabelOnZeWay `label_copy` synchronization; it is independent of physical print copies and ordinary Manifest/archive deletion

## Application details

- App ID: `mg.labelonzeway.app`
- Version: `1.3.3` / version code `8`
- Minimum Android: Android 6 / API 23
- Target and compile SDK: API 35
- Direct printer default: `192.168.100.173:9100`
- Compact 80 mm output: 576 dots and zero added feed by default
- One ESC/POS partial-cut command after every direct-printed label
- Android system printing remains available as an alternative
- The app remains local-first; authorized business data can synchronize through Supabase, while printer settings and active/deferred print queues stay local

## Install or update the test APK

1. Back up/export LabelOnZeWay data as a precaution.
2. Copy `LabelOnZeWay_Android_v1.3.3_Operations_Deck.apk` to the Android phone.
3. On the phone, allow installation from the Files/browser application when Android asks.
4. Open the APK and select **Update** or **Install**.
5. Open **LabelOnZeWay** and confirm that **Back** and **Cancel** appear in the compact phone header.

The v1.3.3 APK is signed with the same Android debug certificate as the physically accepted v1.0.0 APK and the v1.1.0 APK. It can therefore update those builds in place without uninstalling them. Android should retain existing app data during an in-place update. Do not uninstall the existing app unless you have exported a backup, because uninstalling removes device-local data.

This APK is debug-signed for direct physical testing. It is not a Google Play release build.

SHA-256:

```text
ca89afcfccb80dc3c2796e780394f6d1f56b1168980a04eac06a3bddfb1337ab
```

Update from a Mac with Android Platform Tools:

```bash
adb install -r LabelOnZeWay_Android_v1.3.3_Operations_Deck.apk
```

## Printer paths and automatic detection

A network POS80C does not require Internet access, but the phone must still have a local network route to it. Supported direct paths are:

1. **Normal LAN/Wi-Fi:** connect the phone and POS80C to the same reachable network.
2. **Printer Wi-Fi or isolated LAN:** keep the phone connected even if Android says the network has no Internet.
3. **Phone hotspot:** connect the POS80C to the phone's hotspot, then run **AUTO-DETECT POS80C**.

Mobile data alone cannot reach a network-only or Ethernet-only POS80C. Bluetooth or USB printing is not claimed unless the particular printer physically provides and supports that interface.

To detect the printer:

1. Open **More → Settings**.
2. Select **Direct LAN / phone hotspot · ESC/POS**.
3. Confirm raw TCP port `9100` unless the printer uses another configured port.
4. Tap **AUTO-DETECT POS80C**.
5. Choose a discovered address if more than one raw-TCP device is found.
6. Tap **TEST CONNECTION**, then **PRINT & CUT TEST**.

The native scan is bounded to reachable private/link-local local-network `/24` ranges and probes only the chosen raw TCP port. Mobile-data interfaces and public targets are excluded. The scan can be cancelled. A reachable port identifies a raw-TCP endpoint; use **PRINT & CUT TEST** to confirm it is the intended POS80C.

If direct printing fails, the recovery panel provides these choices:

- **Auto-detect & retry**
- **Android system print** through an installed print service
- **Queue for later** on this phone
- **Cancel**

Use the queue control in the compact phone header to retry or clear deferred jobs after the local printer path returns. Queues are separated by LabelOnZeWay profile.

## Physical POS80C regression test

The v1.0.0 build passed physical POS80C acceptance. Repeat this checklist with v1.3.3 because automatic detection, fallback handling, and the newly compiled native code still require a physical Android regression:

1. Connect the phone and POS80C through the same LAN, printer Wi-Fi, or phone hotspot.
2. Open **More → Settings**, run **AUTO-DETECT POS80C**, and confirm the detected printer address.
3. Confirm:
   - Print mode: **Direct LAN / phone hotspot · ESC/POS**
   - Raw TCP port: `9100`
   - Print width: `576`
   - Feed before cut: `0`
   - Cutter: **Partial cut**
   - **Auto-cut after every label**: enabled
4. Tap **TEST CONNECTION**. This checks the raw TCP connection without printing paper.
5. Tap **PRINT & CUT TEST**. Confirm test text prints and the cutter activates.
6. Create one parcel with item quantity `4` and **Label copies** `3`; confirm the saved Manifest keeps those as separate values.
7. Print that parcel and confirm exactly three identical compact labels print consecutively, with no added blank feed and a separate cut after every copy.
8. Select at least two Manifest parcels and confirm **Print selected labels** honors each parcel's copy count.
9. Disconnect the local printer path and verify that a failed job can be queued.
10. Restore the local path, run queue retry, and confirm the deferred label prints once.
11. Select **Android system print** and verify that Android's normal print dialog opens.
12. Verify on-screen **Back**, **Cancel**, and Android hardware back behavior from New Label, Batch, Manifest, and an open dialog.

If discovery or connection fails, confirm that the POS80C is powered on, raw TCP port `9100` is enabled, both devices are on the same reachable subnet, and Wi-Fi client isolation is disabled.

## Mobile workflow check

1. Open **New Label** and confirm the customer step appears before label details.
2. Select an existing customer, or create one and tap **Save & Use**.
3. Confirm the linked customer appears in Label Details and that **Change** returns to customer selection.
4. Enter parcel details and save or save-and-print the label.
5. Enter a **Label copies** value different from item quantity and verify direct and system printing produce that number of physical labels.
6. Open **Batch** and confirm every row clearly labels item quantity, label copies, price, collect, delivery, customer, and payment.
7. Open **Manifest** and confirm it remains centered with no sideways displacement.
8. In **Settings → Company Profiles**, create a test company profile and confirm the app switches to its separate workspace.
9. Use **Back** to return one step and **Cancel** to clear an unsaved label or current batch after confirmation.
10. Expand the optional photo or preview section only when needed.

## Data and backup

Version 1.3.3 is local-first. Run Deep Rescue before clearing or resetting anything; it shows source counts and creates a rescue CSV after merge. The cloud client also blocks accidental mass customer tombstones from an unexpectedly empty local book. It can synchronize authorized business records through a shared Supabase workspace. Printer settings and active/deferred print jobs remain on the Android device. Use Export CSV and Backup before uninstalling or clearing app storage. Installing this correctly signed update over an earlier debug build normally retains app data; uninstalling removes it.

## Build from source

Requirements:

- Node.js 20+
- JDK 21
- Android Studio Ladybug or newer, or a compatible Gradle command-line environment
- Android SDK Platform 35

From the project directory:

```bash
npm ci
npm test
npm run sync
npm run open:android
```

In Android Studio, wait for Gradle synchronization, select an attached Android device, and run the `app` configuration. To make and lint another debug APK from Terminal, run the stages separately:

```bash
cd android
./gradlew assembleDebug
./gradlew lintDebug
```

The generated APK is at `android/app/build/outputs/apk/debug/app-debug.apk`.

## Direct printer implementation

The WebView calls the app-local Capacitor plugin `POS80Printer`. The Java plugin validates private IPv4 targets, opens bounded TCP sockets, decodes the application's base64 ESC/POS job, writes it to the printer, and reports the byte count. Its cancellable discovery method scans attached private/link-local local-network ranges for the selected raw TCP port. The JavaScript renderer creates one compact raster command and one cutter command per selected label; it adds no feed command when feed is set to zero.
