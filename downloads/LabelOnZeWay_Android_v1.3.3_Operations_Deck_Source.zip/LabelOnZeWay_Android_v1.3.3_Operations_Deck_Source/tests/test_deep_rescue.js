const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'www', 'index.html'), 'utf8');
function assert(value, message) { if (!value) throw new Error(message); }
function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

(async () => {
  const downloads = [], errors = [];
  const vc = new VirtualConsole(); vc.on('jsdomError', error => errors.push(error.message));
  const dom = new JSDOM(html, {
    runScripts: 'dangerously', url: 'https://localhost/', pretendToBeVisual: true, virtualConsole: vc,
    beforeParse(w) {
      w.fetch = () => Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
      w.alert = () => {}; w.confirm = () => true; w.prompt = () => null; w.print = () => {}; w.scrollTo = () => {};
      w.matchMedia = () => ({ matches: true, addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} });
      w.HTMLElement.prototype.scrollIntoView = function () {};
      w.HTMLAnchorElement.prototype.click = function () { downloads.push(this.download); };
      w.URL.createObjectURL = () => 'blob:test'; w.URL.revokeObjectURL = () => {};
      w.HTMLCanvasElement.prototype.getContext = function () { return {
        font: '16px Arial', fillRect() {}, fillText() {}, strokeRect() {}, save() {}, restore() {}, setLineDash() {},
        beginPath() {}, moveTo() {}, lineTo() {}, stroke() {}, drawImage() {}, measureText(t) { return { width: String(t).length * 8 }; },
        getImageData(x, y, width, height) { return { data: new w.Uint8ClampedArray(width * height * 4) }; }
      }; };
    }
  });
  await wait(300);
  const w = dom.window;
  w.state.addr = [{ id: 'keep', name: 'Keep Existing', phone: '0340000000', area: '', address: '', note: '' }];
  w.save(w.K('addr'), w.state.addr);
  const sources = {
    'P1.mani': JSON.stringify([{ rec: { name: 'Manifest Rescue', phone: '0343000001', address: 'M' } }]),
    'P1.arch': JSON.stringify([{ rows: [{ recipient: { nom: 'Archive Rescue', telephone: '0343000002', adresse: 'A' } }] }]),
    'P1.labels': JSON.stringify([{ claim: { receiverName: 'Label Rescue', receiverPhone: '0343000003', recipientAddress: 'L' } }]),
    'legacy-json': JSON.stringify({ customers: [{ customerName: 'Legacy Rescue', customerPhone: '0343000004', deliveryAddress: 'J' }] }),
    'lz.cloud.pending.v1': JSON.stringify({ queued: { entity_type: 'customer', payload: { name: 'Queue Rescue', phone: '0343000005', address: 'Q' } } }),
    'P1.shop': JSON.stringify({ name: 'Shop Is Not Customer', phone: '0349999999', address: 'Shop' })
  };
  Object.entries(sources).forEach(([key, value]) => w.localStorage.setItem(key, value));
  const found = w.collectOldAddressBooks();
  assert(found.contacts.length === 5, `Expected 5 deep candidates, got ${found.contacts.length}`);
  assert(!found.sources.some(source => source.key === 'P1.shop'), 'Shop settings were treated as a customer');
  let preview = '';
  w.confirm = message => { preview = message; return false; };
  const before = JSON.stringify(w.state.addr);
  w.recoverOldAddressBooks();
  assert(JSON.stringify(w.state.addr) === before, 'Cancelled recovery mutated customers');
  assert(preview.includes('P1.labels [saved label copies] — 1 record'), 'Preview omitted saved-label source/count');
  w.confirm = () => true;
  const result = w.recoverOldAddressBooks();
  assert(result.added === 5 && w.state.addr.length === 6, 'Deep Rescue did not merge all candidates');
  Object.entries(sources).forEach(([key, value]) => assert(w.localStorage.getItem(key) === value, `Source mutated: ${key}`));
  assert(downloads.some(name => /^labelonzeway-address-book-\d{4}-\d{2}-\d{2}\.csv$/.test(name)), 'CSV safety export missing');
  assert(!w.document.getElementById('fatal').textContent, 'App reported a fatal error');
  assert(!errors.length, `JSDOM errors: ${errors.join('; ')}`);
  dom.window.close();
  console.log(JSON.stringify({ ok: true, deepCandidates: found.contacts.length, added: result.added, sourceDataPreserved: true, automaticCsv: true }, null, 2));
})().catch(error => { console.error(error.stack || error); process.exit(1); });
