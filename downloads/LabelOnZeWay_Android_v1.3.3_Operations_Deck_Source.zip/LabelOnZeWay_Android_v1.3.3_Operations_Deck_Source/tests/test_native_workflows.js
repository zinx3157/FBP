const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(path.join(__dirname, '../www/index.html'), 'utf8');
const calls = { health: [], print: [] };
const errors = [];
const virtualConsole = new VirtualConsole();
virtualConsole.on('jsdomError', error => errors.push(error.message));

const dom = new JSDOM(html, {
  runScripts: 'dangerously',
  url: 'https://localhost/',
  pretendToBeVisual: true,
  virtualConsole,
  beforeParse(window) {
    window.LabelOnZeWayNative = {
      isNative: true,
      platform: 'android',
      printer: {
        health(options) {
          calls.health.push(options);
          return Promise.resolve({ ok: true, printer_ok: true, ...options });
        },
        print(options) {
          calls.print.push(options);
          return Promise.resolve({ ok: true, bytes_sent: Buffer.from(options.data, 'base64').length });
        }
      }
    };
    window.matchMedia = query => ({ matches: false, media: query, addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} });
    window.confirm = () => true;
    window.prompt = () => null;
    window.alert = () => {};
    window.print = () => {};
    window.scrollTo = () => {};
    window.HTMLElement.prototype.scrollIntoView = function () {};
    if (!window.URL.createObjectURL) window.URL.createObjectURL = () => 'blob:test';
    if (!window.URL.revokeObjectURL) window.URL.revokeObjectURL = () => {};
    window.HTMLCanvasElement.prototype.getContext = function () {
      return {
        font: '16px Arial', fillStyle: '#000', strokeStyle: '#000', lineWidth: 1,
        textBaseline: 'top', textAlign: 'left',
        fillRect() {}, fillText() {}, strokeRect() {}, save() {}, restore() {},
        setLineDash() {}, beginPath() {}, moveTo() {}, lineTo() {}, stroke() {}, drawImage() {},
        measureText(text) {
          const match = String(this.font).match(/(\d+)px/);
          return { width: String(text).length * (match ? Number(match[1]) : 16) * 0.55 };
        },
        getImageData(x, y, width, height) {
          const pixels = new window.Uint8ClampedArray(width * height * 4);
          for (let i = 0; i < pixels.length; i += 4) {
            pixels[i] = pixels[i + 1] = pixels[i + 2] = 255;
            pixels[i + 3] = 255;
          }
          return { data: pixels };
        }
      };
    };
  }
});

function row(id, order, name) {
  return {
    id, oid: order, qty: 1, cod: 1000, ship: 3000, pay: 'COD',
    deliverAt: '2026-08-13', deliverTime: '10:30',
    rec: { name, phone: '0340000000', area: 'Tana', address: 'Lot 1', note: 'Call first' },
    addedAt: new Date().toISOString()
  };
}

function countSequence(bytes, sequence) {
  let count = 0;
  for (let i = 0; i <= bytes.length - sequence.length; i++) {
    if (sequence.every((value, offset) => bytes[i + offset] === value)) count++;
  }
  return count;
}

function wait(milliseconds) {
  return new Promise(resolve => setTimeout(resolve, milliseconds));
}

(async () => {
  await wait(250);
  const window = dom.window;
  const document = window.document;

  if (window.state.shop.printMode !== 'direct') throw new Error('Fresh native install is not in direct print mode');
  if (window.state.shop.printerIp !== '192.168.100.173') throw new Error('Expected physical-test printer IP default');
  if (window.state.shop.printerFeed !== 0) throw new Error('Compact output must default to zero added feed');
  if (document.getElementById('native-print-help').textContent.indexOf('no Mac or gateway required') < 0) throw new Error('Native guidance missing');
  if (document.getElementById('download-gateway-btn').style.display !== 'none') throw new Error('Gateway download remains visible in native mode');
  if (!document.getElementById('s-bridge-url').disabled) throw new Error('Gateway URL must be disabled in native mode');

  window.openSettings();
  window.testPrinterBridge();
  await wait(50);
  if (calls.health.length !== 1) throw new Error('Native health plugin was not called exactly once');

  window.state.shop.printMode = 'direct';
  window.state.shop.printerIp = '192.168.100.173';
  window.state.shop.printerPort = 9100;
  window.state.shop.printerCut = 'partial';
  window.state.shop.cutEach = true;
  window.state.shop.printerFeed = 0;
  window.directEscposPrint([row('r1', '0001', 'One'), row('r2', '0002', 'Two')]);
  await wait(700);

  if (calls.print.length !== 1) throw new Error('Native print plugin was not called exactly once');
  const job = calls.print[0];
  const raw = Buffer.from(job.data, 'base64');
  const rasterCommands = countSequence(raw, [29, 118, 48, 0]);
  const partialCuts = countSequence(raw, [29, 86, 66, 0]);
  const feedCommands = countSequence(raw, [29, 74]);
  if (job.printer_ip !== '192.168.100.173' || job.printer_port !== 9100) throw new Error('Wrong native target');
  if (job.labels !== 2 || rasterCommands !== 2) throw new Error('Expected exactly two compact raster labels');
  if (partialCuts !== 2) throw new Error('Expected one partial cut after every label');
  if (feedCommands !== 0) throw new Error('Unexpected blank feed between labels');
  if (window.directPrintBusy) throw new Error('Direct print busy flag did not clear');

  const summary = {
    ok: true,
    nativeHealthCalls: calls.health.length,
    nativePrintCalls: calls.print.length,
    target: `${job.printer_ip}:${job.printer_port}`,
    labels: job.labels,
    bytes: raw.length,
    rasterCommands,
    partialCuts,
    addedFeedCommands: feedCommands,
    systemPrintAlternative: [...document.getElementById('s-print-mode').options].some(option => option.value === 'browser'),
    fatal: document.getElementById('fatal').textContent || null,
    jsdomErrors: errors
  };
  console.log(JSON.stringify(summary, null, 2));
  dom.window.close();
})().catch(error => {
  console.error(error.stack || error);
  dom.window.close();
  process.exit(1);
});
