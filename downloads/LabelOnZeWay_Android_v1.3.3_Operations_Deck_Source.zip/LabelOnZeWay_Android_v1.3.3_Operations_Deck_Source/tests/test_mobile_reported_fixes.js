const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(path.join(__dirname, '../www/index.html'), 'utf8');
const errors = [];
const printPayloads = [];
let systemPrints = 0;
const virtualConsole = new VirtualConsole();
virtualConsole.on('jsdomError', error => errors.push(error.message));

const dom = new JSDOM(html, {
  runScripts: 'dangerously',
  url: 'https://localhost/',
  pretendToBeVisual: true,
  virtualConsole,
  beforeParse(window) {
    window.LabelOnZeWayNative = {
      isNative: true,
      platform: 'android',
      printer: {
        health: options => Promise.resolve({ ok: true, printer_ok: true, ...options }),
        discover: () => Promise.resolve({ ok: true, printers: [] }),
        cancelDiscovery: () => Promise.resolve({ ok: true }),
        print: options => {
          const bytes = Buffer.from(options.data, 'base64');
          printPayloads.push(bytes);
          return Promise.resolve({ ok: true, bytes_sent: bytes.length });
        }
      }
    };
    window.matchMedia = query => ({
      matches: /max-width\s*:\s*780px/.test(query), media: query,
      addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {}
    });
    window.confirm = () => true;
    window.prompt = () => null;
    window.alert = () => {};
    window.print = () => { systemPrints++; };
    window.scrollTo = () => {};
    window.HTMLElement.prototype.scrollIntoView = function () {};
    window.HTMLAnchorElement.prototype.click = function () {};
    if (!window.URL.createObjectURL) window.URL.createObjectURL = () => 'blob:test';
    if (!window.URL.revokeObjectURL) window.URL.revokeObjectURL = () => {};
    window.HTMLCanvasElement.prototype.getContext = function () {
      return {
        font: '16px Arial', fillStyle: '#000', strokeStyle: '#000', lineWidth: 1,
        textBaseline: 'top', textAlign: 'left',
        fillRect() {}, fillText() {}, strokeRect() {}, save() {}, restore() {},
        setLineDash() {}, beginPath() {}, moveTo() {}, lineTo() {}, stroke() {}, drawImage() {},
        measureText(text) { return { width: String(text).length * 8 }; },
        getImageData(x, y, width, height) {
          const pixels = new window.Uint8ClampedArray(width * height * 4);
          for (let i = 0; i < pixels.length; i += 4) {
            pixels[i] = pixels[i + 1] = pixels[i + 2] = 255;
            pixels[i + 3] = 255;
          }
          return { data: pixels };
        }
      };
    };
  }
});

function assert(condition, message) { if (!condition) throw new Error(message); }
function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function countSequence(bytes, seq) {
  let count = 0;
  for (let i = 0; i <= bytes.length - seq.length; i++) {
    if (seq.every((value, offset) => bytes[i + offset] === value)) count++;
  }
  return count;
}

(async () => {
  await wait(250);
  const window = dom.window;
  const document = window.document;

  // Fix 1: phone-safe, explicitly labelled batch layout.
  const toolbar = document.querySelector('#card-batch .batch-toolbar');
  assert(toolbar, 'Clean batch toolbar is missing');
  assert(toolbar.textContent.includes('CUSTOMER FOR ALL LABELS'), 'Batch steps are not clearly ordered');
  assert(toolbar.textContent.includes('ADD PHOTOS'), 'Batch photo action is missing');
  assert(toolbar.textContent.includes('PRINT ALL'), 'Batch print-all action is missing');

  window.state.addr = [{ id: 'a-fix', name: 'Mobile Customer', phone: '0340000000', area: 'Tana', address: 'Centre' }];
  window.state.batch = [{
    id: 'b-fix', qty: 4, copies: 3, price: 8000, cod: 8000, ship: 3000,
    shipManual: false, recId: 'a-fix', pay: 'COD', found: [], status: 'done', msg: 'READY', err: false
  }];
  window.renderBatch();
  const batchRow = document.getElementById('brow-b-fix');
  assert(batchRow, 'Batch row did not render');
  assert(batchRow.textContent.includes('ITEM QTY'), 'Batch item quantity is not labelled');
  assert(batchRow.textContent.includes('LABEL COPIES'), 'Batch label copies are not labelled');
  assert(batchRow.querySelector('.b-qty').value === '4', 'Batch item quantity changed unexpectedly');
  assert(batchRow.querySelector('.b-copies').value === '3', 'Batch copies value did not render');
  assert(batchRow.querySelectorAll('.b-actions .btn').length === 4, 'Readable batch actions are missing');

  // Fix 2: copies remain distinct from quantity and expand into physical labels.
  const row = {
    id: 'r-fix', oid: '0123', qty: 4, copies: 3, cod: 8000, ship: 3000, pay: 'COD',
    addedAt: new Date().toISOString(), deliverAt: '2026-08-14', deliverTime: '', done: false,
    rec: { name: 'Mobile Customer', phone: '0340000000', area: 'Tana', address: 'Centre' }
  };
  window.state.manifest = [row];
  window.renderManifest();
  const copiesField = document.querySelector('.mobile-field input[onchange*="copies"]');
  assert(copiesField && copiesField.value === '3', 'Manifest label-copies editor is missing');
  assert(row.qty === 4 && row.copies === 3, 'Item quantity and label copies are not separate');

  window.state.shop.printMode = 'direct';
  window.state.shop.printerIp = '192.168.100.173';
  window.state.shop.printerFeed = 0;
  window.state.shop.printerCut = 'partial';
  window.state.shop.cutEach = true;
  window.doPrint('label', window.labelHTML(row), [row]);
  await wait(500);
  assert(printPayloads.length === 1, 'Direct copies were not sent as one print job');
  assert(countSequence(printPayloads[0], [29, 118, 48, 0]) === 3, 'Three physical label rasters were not generated');
  assert(countSequence(printPayloads[0], [29, 86, 66, 0]) === 3, 'Printer was not instructed to cut after every copy');
  assert(countSequence(printPayloads[0], [29, 74]) === 0, 'Unexpected blank-feed command was added between copies');

  window.doPrint('label', window.labelHTML(row), [row], true);
  await wait(250);
  assert(systemPrints === 1, 'System print fallback did not open');
  assert(document.querySelectorAll('#print-root .lbl').length === 3, 'System print did not receive three label copies');

  // Fix 3: manifest has explicit centered, overflow-safe phone constraints.
  const css = Array.from(document.querySelectorAll('style')).map(s => s.textContent).join('\n');
  assert(css.includes('#card-batch,#card-manifest{width:100%;max-width:100%;min-width:0;margin-left:auto;margin-right:auto;overflow:hidden}'), 'Centered manifest phone constraint is missing');
  assert(css.includes('grid-template-columns:minmax(0,1fr)'), 'Phone app grid can still overflow horizontally');
  window.showMobileView('manifest');
  assert(document.getElementById('card-manifest').classList.contains('mobile-view-active'), 'Centered manifest view did not activate');

  // Fix 4: profile creation is available inside mobile settings without prompt().
  window.openSettings();
  const profileInput = document.getElementById('s-new-profile');
  const profileButton = document.querySelector('[data-act="addProfileFromSettings"]');
  assert(profileInput && profileButton, 'In-settings company profile form is missing');
  const profileResult = window.createProfile('Mobile Company');
  assert(profileResult.ok, 'Company profile could not be created');
  const profiles = JSON.parse(window.localStorage.getItem('lz.profiles'));
  assert(profiles.some(profile => profile.name === 'Mobile Company'), 'New company profile was not stored');
  assert(window.localStorage.getItem('lz.profile') === profileResult.id, 'App did not switch to the new profile');
  const newShop = JSON.parse(window.localStorage.getItem(profileResult.id + '.shop'));
  assert(newShop.name === 'Mobile Company', 'New profile was not initialized with its company name');

  assert(document.querySelector('#mobile-context [data-act="mobileBack"]'), 'Back control was removed');
  assert(document.querySelector('#mobile-context [data-act="cancelMobile"]'), 'Cancel control was removed');
  assert(!document.getElementById('fatal').textContent, `Fatal UI error: ${document.getElementById('fatal').textContent}`);
  assert(!errors.length, `jsdom errors: ${errors.join('; ')}`);

  console.log(JSON.stringify({
    ok: true,
    cleanBatchLayout: true,
    itemQuantity: row.qty,
    labelCopies: row.copies,
    directRasters: countSequence(printPayloads[0], [29, 118, 48, 0]),
    cutsAfterCopies: countSequence(printPayloads[0], [29, 86, 66, 0]),
    addedFeedCommands: countSequence(printPayloads[0], [29, 74]),
    systemPrintCopies: document.querySelectorAll('#print-root .lbl').length,
    centeredManifest: true,
    mobileProfileCreated: profileResult.name,
    backAndCancelPreserved: true
  }, null, 2));
  dom.window.close();
})().catch(error => {
  console.error(error.stack || error);
  dom.window.close();
  process.exit(1);
});
