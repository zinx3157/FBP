#!/usr/bin/env python3
"""Static Android/native integrity checks that do not require an emulator."""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks = []

def check(name, condition):
    if not condition:
        raise AssertionError(f"{name}: failed")
    checks.append(name)

package = json.loads((ROOT / "package.json").read_text())
config = json.loads((ROOT / "capacitor.config.json").read_text())
gradle = (ROOT / "android/app/build.gradle").read_text()
plugin = (ROOT / "android/app/src/main/java/mg/labelonzeway/app/POS80PrinterPlugin.java").read_text()
manifest = (ROOT / "android/app/src/main/AndroidManifest.xml").read_text()
web = (ROOT / "www/index.html").read_bytes()
public_web = (ROOT / "android/app/src/main/assets/public/index.html").read_bytes()

check("Package version", package["version"] == "1.3.3")
check("Capacitor bundle ID", config["appId"] == "mg.labelonzeway.app")
check("Android version code", bool(re.search(r"versionCode\s+8\b", gradle)))
check("Android version name", 'versionName "1.3.3"' in gradle)
check("Internet permission", "android.permission.INTERNET" in manifest)
check("Raw TCP bridge", "new Socket()" in plugin and "OutputStream" in plugin)
check("Direct-print bounds", "CONNECT_TIMEOUT_MS = 8_000" in plugin and "WRITE_TIMEOUT_MS = 45_000" in plugin)
check("Native discovery methods", "public void discover(PluginCall call)" in plugin and "public void cancelDiscovery(PluginCall call)" in plugin)
check("Bounded native discovery", "MAXIMUM_DISCOVERY_NETWORKS = 4" in plugin and "DISCOVERY_TOTAL_TIMEOUT_MS = 20_000" in plugin)
check("Cancellable native discovery", "activeDiscovery" in plugin and "shutdownNow()" in plugin)
check("Generated public web current", web == public_web)
check(
    "Generated bridge current",
    (ROOT / "www/native-bridge.bundle.js").read_bytes()
    == (ROOT / "android/app/src/main/assets/public/native-bridge.bundle.js").read_bytes(),
)
check(
    "Cloud client current",
    (ROOT / "www/cloud-sync.js").read_bytes()
    == (ROOT / "android/app/src/main/assets/public/cloud-sync.js").read_bytes(),
)
html = web.decode()
check("Claims Vault UI", "Claims Vault" in html and "labelVault" in html)
check("Auto-detect UI", "AUTO-DETECT POS80C" in html and "cancelPrinterDiscovery" in html)

print(json.dumps({"ok": True, "checks": len(checks), "results": checks}, indent=2))
