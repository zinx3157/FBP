const {JSDOM,VirtualConsole}=require('jsdom'),fs=require('fs');
const html=fs.readFileSync(require('path').join(__dirname,'../www/index.html'),'utf8');
const vc=new VirtualConsole(),errors=[];vc.on('jsdomError',e=>errors.push(e.message));
const dom=new JSDOM(html,{runScripts:'dangerously',url:'https://test.local/',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
 w.confirm=()=>false;w.prompt=()=>null;w.alert=()=>{};w.print=()=>{};w.scrollTo=()=>{};w.matchMedia=()=>({matches:false,addListener(){},removeListener(){}});
 w.HTMLElement.prototype.scrollIntoView=function(){};w.HTMLAnchorElement.prototype.click=function(){};
 if(!w.URL.createObjectURL)w.URL.createObjectURL=()=> 'blob:test';if(!w.URL.revokeObjectURL)w.URL.revokeObjectURL=()=>{};
 w.HTMLCanvasElement.prototype.getContext=function(){return{font:'16px Arial',fillStyle:'#000',strokeStyle:'#000',lineWidth:1,textBaseline:'top',textAlign:'left',fillRect(){},fillText(){},strokeRect(){},save(){},restore(){},setLineDash(){},beginPath(){},moveTo(){},lineTo(){},stroke(){},drawImage(){},measureText(text){var m=String(this.font).match(/(\d+)px/);return{width:String(text).length*(m?Number(m[1]):16)*0.55}},getImageData(x,y,width,height){var pixels=new w.Uint8ClampedArray(width*height*4);for(var i=0;i<pixels.length;i+=4){pixels[i]=pixels[i+1]=pixels[i+2]=255;pixels[i+3]=255}return{data:pixels}}}};
}});
setTimeout(()=>{
 const w=dom.window,d=w.document,failed=[],clicked=[];
 const acts=[...new Set([...html.matchAll(/data-act=["']([^"']+)/g)].map(m=>m[1]))];
 for(const b of [...d.querySelectorAll('button')]){const label=b.dataset.act||b.dataset.close||b.id||b.textContent.trim();try{b.click();clicked.push(label)}catch(e){failed.push({label,error:e.message})}}
 const row=(id,oid)=>({id,oid,qty:1,cod:1000,ship:3000,pay:'MVola',rec:{name:'Test',phone:'0340000000',area:'Tana',address:'Lot 1',note:''},addedAt:new Date().toISOString(),done:false});
 w.state.manifest=[row('r1','0001'),row('r2','0002')];w.renderManifest();const checks=[...d.querySelectorAll('.mani-select')];checks[0].checked=true;checks[0].dispatchEvent(new w.Event('change',{bubbles:true}));d.getElementById('print-selected-labels').click();
 setTimeout(()=>{
   console.log(JSON.stringify({title:d.title,brand:d.querySelector('.brand h1').textContent,buttons:clicked.length,failed,missingActions:acts.filter(a=>a!=='profile'&&typeof w.ACTIONS[a]!=='function'),
    paymentOptions:[...d.getElementById('f-pay').options].length,selected:w.selectedManifestRows().length,printedLabels:d.querySelectorAll('#print-root .lbl').length,
    printModes:[...d.getElementById('s-print-mode').options].map(o=>o.value),mobileNavButtons:d.querySelectorAll('#mobile-nav button').length,
    manifestLink:!!d.querySelector('link[rel=manifest]'),fatal:d.getElementById('fatal').textContent||null,errors},null,2));dom.window.close();
 },200);
},250);
