const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(path.join(__dirname, '../www/index.html'), 'utf8');
const errors = [];
const virtualConsole = new VirtualConsole();
virtualConsole.on('jsdomError', error => errors.push(error.message));

const dom = new JSDOM(html, {
  runScripts: 'dangerously',
  url: 'https://localhost/',
  pretendToBeVisual: true,
  virtualConsole,
  beforeParse(window) {
    window.LabelOnZeWayNative = {
      isNative: true,
      platform: 'android',
      printer: {
        health: options => Promise.resolve({ ok: true, ...options }),
        print: options => Promise.resolve({ ok: true, bytes_sent: Buffer.from(options.data, 'base64').length })
      }
    };
    window.matchMedia = query => ({
      matches: /max-width\s*:\s*780px/.test(query),
      media: query,
      addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {}
    });
    window.confirm = () => true;
    window.prompt = () => null;
    window.alert = () => {};
    window.print = () => {};
    window.scrollTo = () => {};
    window.HTMLElement.prototype.scrollIntoView = function () {};
    window.HTMLAnchorElement.prototype.click = function () {};
    if (!window.URL.createObjectURL) window.URL.createObjectURL = () => 'blob:test';
    if (!window.URL.revokeObjectURL) window.URL.revokeObjectURL = () => {};
    window.HTMLCanvasElement.prototype.getContext = function () {
      return {
        font: '16px Arial', fillStyle: '#000', strokeStyle: '#000', lineWidth: 1,
        textBaseline: 'top', textAlign: 'left',
        fillRect() {}, fillText() {}, strokeRect() {}, save() {}, restore() {},
        setLineDash() {}, beginPath() {}, moveTo() {}, lineTo() {}, stroke() {}, drawImage() {},
        measureText(text) {
          const match = String(this.font).match(/(\d+)px/);
          return { width: String(text).length * (match ? Number(match[1]) : 16) * 0.55 };
        },
        getImageData(x, y, width, height) {
          const pixels = new window.Uint8ClampedArray(width * height * 4);
          for (let i = 0; i < pixels.length; i += 4) {
            pixels[i] = pixels[i + 1] = pixels[i + 2] = 255;
            pixels[i + 3] = 255;
          }
          return { data: pixels };
        }
      };
    };
  }
});

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function wait(milliseconds) {
  return new Promise(resolve => setTimeout(resolve, milliseconds));
}

(async () => {
  await wait(300);
  const window = dom.window;
  const document = window.document;

  assert(document.body.classList.contains('mobile-ui-ready'), 'Mobile UI did not initialize');
  assert(!document.getElementById('photo-tools').open, 'Optional photo tools should start collapsed on mobile');
  assert(document.getElementById('card-preview').classList.contains('mobile-collapsed'), 'Large label preview should start collapsed');
  assert(document.getElementById('rec-select').value === '', 'Customer selector should start with a neutral prompt');
  assert(!document.getElementById('rec-form').classList.contains('open'), 'New-customer form should not consume space initially');
  assert(window.mobileView === 'home', 'Operations Deck should open on Home');
  assert(document.getElementById('card-home').classList.contains('mobile-view-active'), 'Home card should be active initially');

  window.showMobileView('new');
  let active = [...document.querySelectorAll('#app > .mobile-view-active')].map(el => el.id).sort();
  assert(JSON.stringify(active) === JSON.stringify(['card-parcel', 'card-preview', 'card-recipient']), 'New-label mobile view is not isolated from long batch/manifest content');

  window.toggleRecForm();
  document.getElementById('r-name').value = 'Mobile Customer';
  document.getElementById('r-phone').value = '0341112233';
  document.getElementById('r-area').value = 'Analakely';
  document.getElementById('r-addr').value = 'Lot Mobile 1';
  document.getElementById('r-note').value = 'Call first';
  window.quickSaveRec();
  await wait(120);

  assert(window.state.addr.length === 1, 'New mobile customer was not saved');
  assert(window.currentRec() && window.currentRec().name === 'Mobile Customer', 'New customer was not linked to the current label');
  assert(document.getElementById('customer-step-status').classList.contains('ready'), 'Customer step did not show completion');
  assert(document.getElementById('card-recipient').classList.contains('mobile-collapsed'), 'Completed customer step did not compact itself');
  assert(document.getElementById('linked-customer-name').textContent === 'Mobile Customer', 'Label-details customer summary is stale');
  assert(document.getElementById('pv-sheet').textContent.includes('Mobile Customer'), 'Live label preview did not receive the new customer');
  assert(document.getElementById('pv-sheet').textContent.includes('Lot Mobile 1'), 'Live label preview did not receive the customer address');

  document.getElementById('f-qty').value = '2';
  document.getElementById('f-price').value = '15000';
  document.getElementById('f-cod').value = '15000';
  window.addToManifest(false);
  assert(window.state.manifest.length === 1, 'Coordinated customer/label record was not added');
  assert(window.state.manifest[0].rec.name === 'Mobile Customer', 'Saved label lost its linked customer snapshot');
  assert(window.state.manifest[0].qty === 2 && window.state.manifest[0].cod === 15000, 'Saved label lost label details');

  window.showMobileView('manifest');
  active = [...document.querySelectorAll('#app > .mobile-view-active')].map(el => el.id);
  assert(active.length === 1 && active[0] === 'card-manifest', 'Manifest tab did not replace the new-label view');
  assert(document.querySelectorAll('.mobile-manifest-item').length === 1, 'Compact mobile manifest card was not rendered');
  assert(document.querySelector('.mobile-manifest-item summary').textContent.includes('Mobile Customer'), 'Manifest card is missing customer coordination');
  assert(document.querySelector('[data-view="manifest"]').getAttribute('aria-current') === 'true', 'Bottom navigation state is not accessible');

  window.showMobileView('batch');
  active = [...document.querySelectorAll('#app > .mobile-view-active')].map(el => el.id);
  assert(active.length === 1 && active[0] === 'card-batch', 'Batch tab did not isolate batch workflow');

  const summary = {
    ok: true,
    mobileViews: ['new', 'batch', 'manifest'],
    newViewCards: 3,
    optionalPhotoCollapsed: true,
    previewCollapsed: true,
    customerSavedAndLinked: window.state.addr.length,
    manifestCards: document.querySelectorAll('.mobile-manifest-item').length,
    compactFieldPairs: document.querySelectorAll('#card-parcel .mobile-pair').length,
    fatal: document.getElementById('fatal').textContent || null,
    jsdomErrors: errors
  };
  assert(!summary.fatal, `Fatal UI error: ${summary.fatal}`);
  assert(!errors.length, `jsdom errors: ${errors.join('; ')}`);
  console.log(JSON.stringify(summary, null, 2));
  dom.window.close();
})().catch(error => {
  console.error(error.stack || error);
  dom.window.close();
  process.exit(1);
});
