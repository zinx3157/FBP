const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(path.join(__dirname, '../www/index.html'), 'utf8');
const errors = [];
const calls = { discover: 0, cancel: 0, print: 0, systemPrint: 0 };
const virtualConsole = new VirtualConsole();
virtualConsole.on('jsdomError', error => errors.push(error.message));

const dom = new JSDOM(html, {
  runScripts: 'dangerously',
  url: 'https://localhost/',
  pretendToBeVisual: true,
  virtualConsole,
  beforeParse(window) {
    window.LabelOnZeWayNative = {
      isNative: true,
      platform: 'android',
      printer: {
        health: options => Promise.resolve({ ok: true, printer_ok: true, ...options }),
        discover: options => {
          calls.discover++;
          return Promise.resolve({
            ok: true,
            cancelled: false,
            networks: ['192.168.43.0/24'],
            printers: [{ ip: '192.168.43.173', port: options.printer_port || 9100, connect_ms: 5 }]
          });
        },
        cancelDiscovery: () => { calls.cancel++; return Promise.resolve({ ok: true, cancelled: true }); },
        print: options => {
          calls.print++;
          return Promise.resolve({ ok: true, bytes_sent: Buffer.from(options.data, 'base64').length });
        }
      }
    };
    window.matchMedia = query => ({
      matches: /max-width\s*:\s*780px/.test(query),
      media: query,
      addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {}
    });
    window.confirm = () => true;
    window.prompt = () => null;
    window.alert = () => {};
    window.print = () => { calls.systemPrint++; };
    window.scrollTo = () => {};
    window.HTMLElement.prototype.scrollIntoView = function () {};
    window.HTMLAnchorElement.prototype.click = function () {};
    if (!window.URL.createObjectURL) window.URL.createObjectURL = () => 'blob:test';
    if (!window.URL.revokeObjectURL) window.URL.revokeObjectURL = () => {};
    window.HTMLCanvasElement.prototype.getContext = function () {
      return {
        font: '16px Arial', fillStyle: '#000', strokeStyle: '#000', lineWidth: 1,
        textBaseline: 'top', textAlign: 'left',
        fillRect() {}, fillText() {}, strokeRect() {}, save() {}, restore() {},
        setLineDash() {}, beginPath() {}, moveTo() {}, lineTo() {}, stroke() {}, drawImage() {},
        measureText(text) { return { width: String(text).length * 8 }; },
        getImageData(x, y, width, height) {
          const pixels = new window.Uint8ClampedArray(width * height * 4);
          for (let i = 0; i < pixels.length; i += 4) {
            pixels[i] = pixels[i + 1] = pixels[i + 2] = 255;
            pixels[i + 3] = 255;
          }
          return { data: pixels };
        }
      };
    };
  }
});

function assert(condition, message) {
  if (!condition) throw new Error(message);
}
function wait(milliseconds) { return new Promise(resolve => setTimeout(resolve, milliseconds)); }

(async () => {
  await wait(250);
  const window = dom.window;
  const document = window.document;

  assert(document.getElementById('mobile-context'), 'Back/Cancel mobile context bar is missing');
  assert(document.querySelector('#mobile-context [data-act="mobileBack"]'), 'Back control is missing');
  assert(document.querySelector('#mobile-context [data-act="cancelMobile"]'), 'Cancel control is missing');
  assert(document.getElementById('manifest-action-menu'), 'Compact manifest menu is missing');
  assert(document.getElementById('discover-printer-btn'), 'Auto-detect printer control is missing');
  assert(document.getElementById('cancel-discovery-btn'), 'Cancel discovery control is missing');
  assert(document.getElementById('m-print-fallback'), 'Off-network print fallback is missing');

  window.showMobileView('manifest');
  assert(window.mobileView === 'manifest', 'Manifest view did not open');
  assert(window.mobileGoBack() === true && window.mobileView === 'new', 'Back did not return from manifest to new label');

  document.getElementById('card-recipient').classList.add('mobile-collapsed');
  assert(window.mobileGoBack() === true, 'Back did not handle the completed customer step');
  assert(!document.getElementById('card-recipient').classList.contains('mobile-collapsed'), 'Back did not reopen the previous customer step');

  document.getElementById('f-price').value = '9000';
  document.getElementById('f-cod').value = '9000';
  window.cancelMobile();
  assert(document.getElementById('f-price').value === '', 'Cancel did not clear unsaved price');
  assert(document.getElementById('f-cod').value === '', 'Cancel did not clear unsaved collect amount');

  window.openSettings();
  document.getElementById('s-printer-port').value = '9100';
  await window.discoverPrinter({ useForm: true, silent: false });
  assert(calls.discover === 1, 'Native printer discovery was not called');
  assert(window.state.shop.printerIp === '192.168.43.173', 'Detected printer was not selected and saved');
  assert(document.getElementById('s-printer-ip').value === '192.168.43.173', 'Detected printer did not update manual IP input');
  assert(document.getElementById('printer-discovery-results').textContent.includes('192.168.43.173'), 'Detected printer result is not visible');
  window.closeModal('m-settings');

  const row = {
    id: 'queue-row', oid: '0099', qty: 1, cod: 9000, ship: 3000, pay: 'COD',
    deliverAt: '2026-08-14', deliverTime: '', rec: { name: 'Queue Customer', phone: '0340000000', address: 'Antananarivo', area: '' }
  };
  window.openPrintFallback([row], 'offline test');
  assert(document.getElementById('m-print-fallback').classList.contains('open'), 'Fallback menu did not open');
  window.queueFailedPrint();
  assert(window.getPrintQueue().length === 1, 'Failed label was not queued');
  assert(document.querySelector('.queue-count-label').textContent.includes('1'), 'Queue count did not update');

  window.retryPrintQueue();
  await wait(500);
  assert(calls.print === 1, 'Queued print was not sent directly');
  assert(window.getPrintQueue().length === 0, 'Successful queued print was not removed');

  window.openPrintFallback([row], 'system print test');
  window.systemPrintFallback();
  await wait(250);
  assert(calls.systemPrint === 1, 'Android system-print fallback did not open');

  assert(typeof window.handleNativeBack === 'function', 'Native Android back handler is missing');
  assert(!document.getElementById('fatal').textContent, `Fatal UI error: ${document.getElementById('fatal').textContent}`);
  assert(!errors.length, `jsdom errors: ${errors.join('; ')}`);

  console.log(JSON.stringify({
    ok: true,
    backAndCancel: true,
    compactManifestMenu: true,
    discoveredPrinter: window.state.shop.printerIp,
    discoveryCalls: calls.discover,
    queuedDirectPrints: calls.print,
    systemPrintFallbacks: calls.systemPrint
  }, null, 2));
  dom.window.close();
})().catch(error => {
  console.error(error.stack || error);
  dom.window.close();
  process.exit(1);
});
