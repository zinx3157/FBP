const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('fs');
const path = require('path');

function assert(condition, message) {
  if (!condition) throw new Error(message);
}
function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

(async () => {
  const html = fs.readFileSync(path.resolve(__dirname, '..', 'www', 'index.html'), 'utf8');
  const errors = [];
  let printCalls = 0;
  const consolePipe = new VirtualConsole();
  consolePipe.on('jsdomError', error => errors.push(error.message));
  const dom = new JSDOM(html, {
    runScripts: 'dangerously',
    url: 'https://native-app.test/',
    pretendToBeVisual: true,
    virtualConsole: consolePipe,
    beforeParse(window) {
      window.matchMedia = () => ({ matches: true, addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} });
      window.confirm = () => true;
      window.prompt = () => null;
      window.alert = () => {};
      window.print = () => { printCalls++; };
      window.scrollTo = () => {};
      window.HTMLElement.prototype.scrollIntoView = function () {};
      if (!window.URL.createObjectURL) window.URL.createObjectURL = () => 'blob:test';
      if (!window.URL.revokeObjectURL) window.URL.revokeObjectURL = () => {};
      Object.defineProperty(window.navigator, 'serviceWorker', { configurable: true, value: { register: () => Promise.resolve({}) } });
      window.fetch = () => Promise.reject(new Error('Network is intentionally disabled in the claim-vault test'));
      window.HTMLCanvasElement.prototype.getContext = function () {
        return {
          font: '16px Arial', fillStyle: '#000', strokeStyle: '#000', lineWidth: 1,
          textBaseline: 'top', textAlign: 'left',
          fillRect() {}, fillText() {}, strokeRect() {}, save() {}, restore() {},
          setLineDash() {}, beginPath() {}, moveTo() {}, lineTo() {}, stroke() {}, drawImage() {},
          measureText(text) { return { width: String(text).length * 8 }; },
          getImageData(x, y, width, height) {
            const pixels = new window.Uint8ClampedArray(width * height * 4);
            for (let i = 0; i < pixels.length; i += 4) pixels[i] = pixels[i + 1] = pixels[i + 2] = pixels[i + 3] = 255;
            return { data: pixels };
          }
        };
      };
    }
  });
  await wait(300);
  const w = dom.window;
  const d = w.document;
  assert(Array.isArray(w.state.labelVault), 'Permanent Label Claims Vault state is missing');
  assert(d.querySelector('[data-act="openLabelVault"]'), 'Claims Vault action is missing');

  w.state.shop.name = 'Historical Claims Company';
  w.state.shop.tagline = 'Original label identity';
  w.state.shop.phone = '0340000000';
  w.state.shop.copies = 12;
  const row = {
    id: 'parcel-claim-1', oid: '0412', qty: 5, copies: 12, cod: 12000, ship: 3000, pay: 'COD',
    addedAt: '2026-08-15T08:00:00.000Z', deliverAt: '2026-08-16', deliverTime: '09:00',
    rec: { id: 'customer-claim-1', name: 'Claims Customer', phone: '0341111111', area: 'Analakely', address: 'Original Address', note: 'Claim source' }
  };
  assert(w.storeLabelCopies([row], 'created', false) === 1, 'Creating a label did not retain a permanent electronic copy');
  assert(w.state.labelVault.length === 1, 'Unexpected number of first claim versions');
  const first = w.state.labelVault[0];
  assert(!Object.prototype.hasOwnProperty.call(first.row, 'copies'), 'Claim fingerprint retained the physical 1–20 print quantity');

  w.storeLabelCopies([Object.assign({}, row, { copies: 2 })], 'copy-setting-only', false);
  assert(w.state.labelVault.length === 1, 'Changing only physical label copies created a false claim version');
  const corrected = Object.assign({}, row, { rec: Object.assign({}, row.rec, { address: 'Corrected Address' }) });
  w.storeLabelCopies([corrected], 'corrected', false);
  assert(w.state.labelVault.length === 2, 'Corrected label was not retained as another version');
  assert(w.state.labelVault.some(entry => entry.version === 1) && w.state.labelVault.some(entry => entry.version === 2),
    'Claim versions were not independently numbered');

  w.state.manifest = [];
  w.state.archive = [];
  w.persist();
  const persisted = JSON.parse(w.localStorage.getItem('P1.labels'));
  assert(persisted.length === 2, 'Manifest/archive removal deleted claim copies');

  w.state.shop.name = 'Current Company Changed Later';
  w.previewClaimLabel(first.id);
  assert(d.getElementById('preview-title').textContent.includes('CLAIM COPY'), 'Claim preview did not open');
  assert(d.getElementById('preview-body').textContent.includes('Historical Claims Company'),
    'Claim preview used current company details instead of the saved historical identity');
  assert(d.getElementById('preview-body').textContent.includes('Original Address'), 'Claim preview did not preserve the original recipient address');
  w.printPreviewNow();
  await wait(260);
  assert(printCalls === 1, 'Claim reprint did not use the system print path');
  assert(d.querySelectorAll('#print-root .lbl').length === 1, 'Claim reprint produced more than one physical copy');
  assert(w.state.labelVault.length === 2, 'Reprinting a claim incorrectly created another label version');
  assert(w.state.labelVault.find(entry => entry.id === first.id).printCount === 1, 'Claim reprint history was not updated');

  assert(/labelVault:state\.labelVault/.test(html), 'Backup payload omits permanent claim copies');
  assert(/Array\.isArray\(d\.labelVault\)/.test(html), 'Restore workflow omits permanent claim copies');
  assert(/no automatic expiry/i.test(html), 'Claims Vault does not disclose permanent retention');
  assert(!d.getElementById('fatal').textContent, `Application fatal error: ${d.getElementById('fatal').textContent}`);
  assert(!errors.length, `jsdom errors: ${errors.join('; ')}`);
  dom.window.close();

  console.log(JSON.stringify({
    ok: true,
    permanentVersions: 2,
    physicalCopiesExcludedFromFingerprint: true,
    survivesManifestArchiveDeletion: true,
    historicalCompanyAndRecipientRetained: true,
    oneCopySystemReprint: true,
    backupRestoreIncluded: true
  }, null, 2));
})().catch(error => {
  console.error(error.stack || error);
  process.exit(1);
});
