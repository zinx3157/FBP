const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('fs');
const path = require('path');

const appDir = path.resolve(__dirname, '../www');
const html = fs.readFileSync(path.join(appDir, 'index.html'), 'utf8');
function assert(value, message) { if (!value) throw new Error(message); }
function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

(async () => {
  const jsdomErrors = [];
  const confirmations = [];
  let confirmResult = true;
  const virtualConsole = new VirtualConsole();
  virtualConsole.on('jsdomError', error => jsdomErrors.push(error.message));
  const dom = new JSDOM(html, {
    runScripts: 'dangerously',
    url: 'https://zinx3157.github.io/FBP/labelonzeway/',
    pretendToBeVisual: true,
    virtualConsole,
    beforeParse(window) {
      window.matchMedia = query => ({
        matches: /max-width\s*:\s*780px/.test(query), media: query,
        addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {}
      });
      window.confirm = message => { confirmations.push(String(message)); return confirmResult; };
      window.alert = () => {};
      window.prompt = () => null;
      window.scrollTo = () => {};
      window.print = () => {};
      window.fetch = () => Promise.reject(new Error('No network expected'));
      window.HTMLElement.prototype.scrollIntoView = function () {};
      Object.defineProperty(window.navigator, 'serviceWorker', {
        configurable: true,
        value: { register() { return Promise.resolve({}); } }
      });
      window.HTMLCanvasElement.prototype.getContext = function () {
        return {
          font: '16px Arial', fillStyle: '#000', strokeStyle: '#000', lineWidth: 1,
          textBaseline: 'top', textAlign: 'left', fillRect() {}, fillText() {}, strokeRect() {},
          save() {}, restore() {}, setLineDash() {}, beginPath() {}, moveTo() {}, lineTo() {}, stroke() {}, drawImage() {},
          measureText(text) { return { width: String(text).length * 8 }; },
          getImageData(x, y, width, height) {
            const pixels = new window.Uint8ClampedArray(width * height * 4);
            return { data: pixels };
          }
        };
      };
    }
  });

  await wait(300);
  const w = dom.window;
  const d = w.document;

  assert(d.body.classList.contains('mobile-ui-ready'), 'Mobile Operations Deck did not initialize');
  assert(w.mobileView === 'home', 'Home is not the initial phone destination');
  assert(d.getElementById('card-home').classList.contains('mobile-view-active'), 'Home card is not active');
  assert(d.getElementById('card-home').getAttribute('data-mobile-view') === 'home', 'Home route hook is missing');
  assert(d.getElementById('card-more').getAttribute('data-mobile-view') === 'more', 'More route hook is missing');
  assert(d.querySelector('.brand[data-act="showMobileView"][data-arg="home"]'), 'Clickable Home brand is missing');

  const routes = [...d.querySelectorAll('#mobile-nav button')].map(button => ({
    route: button.getAttribute('data-arg'), label: button.textContent.replace(/\s+/g, ' ').trim()
  }));
  assert(routes.length === 5, 'Operations Deck must expose five phone destinations');
  ['home', 'new', 'batch', 'manifest', 'more'].forEach(route => {
    assert(routes.some(item => item.route === route), `Missing phone route: ${route}`);
  });
  ['HOME', 'NEW LABEL', 'BATCH', 'MANIFEST', 'MORE'].forEach(label => {
    assert(routes.some(item => item.label.includes(label)), `Missing explicit navigation label: ${label}`);
  });

  ['quickSystemPrint', 'quickDirectPrint', 'quickDetectPrinter', 'openCloud', 'openLabelVault',
    'recoverOldAddressBooks', 'exportAddressBookCSV', 'openSettings', 'openArch'].forEach(action => {
    assert(d.querySelector(`[data-act="${action}"]`), `Operations Deck action missing: ${action}`);
    assert(typeof w.ACTIONS[action] === 'function', `Operations Deck action is not registered: ${action}`);
  });
  assert(typeof w.ACTIONS.deleteSelectedBatch === 'function', 'Selected Batch deletion action is not registered');
  assert(typeof w.ACTIONS.deleteSelectedManifestLabels === 'function', 'Selected Manifest deletion action is not registered');

  w.showMobileView('more');
  assert(w.mobileView === 'more' && d.getElementById('card-more').classList.contains('mobile-view-active'), 'More route failed');
  assert(w.mobileGoBack() === true && w.mobileView === 'new', 'Back from More did not preserve the established New Label return path');
  w.showMobileView('home');
  assert(w.mobileGoBack() === false && w.mobileView === 'home', 'Back should be disabled on Home');

  w.quickDirectPrint();
  assert(w.state.shop.printMode === 'direct', 'Direct POS80C quick action did not use device-local print mode');
  w.quickSystemPrint();
  assert(w.state.shop.printMode === 'browser', 'System Print quick action did not use device-local print mode');

  w.state.addr = [
    { id: 'c-a', name: 'Alpha Recipient', phone: '0340000001', area: 'A', address: 'Lot A', note: '' },
    { id: 'c-b', name: 'Beta Recipient', phone: '0340000002', area: 'B', address: 'Lot B', note: '' }
  ];
  w.state.batch = [
    { id: 'b-a', sourceOid: '0421', recId: 'c-a', qty: 1, copies: 1, price: 1000, cod: 1000, ship: 0, pay: 'COD', status: 'done', found: [] },
    { id: 'b-b', fileRef: { name: 'beta-photo.jpg' }, recId: 'c-b', qty: 1, copies: 1, price: 2000, cod: 2000, ship: 0, pay: 'COD', status: 'done', found: [] }
  ];
  w.renderBatch();
  assert(d.querySelectorAll('#batch-list .b-select input').length === 2, 'Batch selection checkboxes are not visible per label');
  w.setBatchSelected('b-a', true);
  assert(!d.getElementById('batch-delete-selected').disabled, 'Selected Batch deletion control remained disabled');
  assert(d.getElementById('batch-delete-selected').textContent.includes('(1)'), 'Selected Batch count did not update');

  confirmResult = false;
  w.deleteSelectedBatch();
  assert(w.state.batch.length === 2, 'Cancelled Batch deletion removed a staged label');
  assert(confirmations.at(-1).includes('order #0421') && confirmations.at(-1).includes('Alpha Recipient'),
    'Batch deletion confirmation did not identify the exact staged label');

  confirmResult = true;
  w.deleteSelectedBatch();
  assert(w.state.batch.length === 1 && w.state.batch[0].id === 'b-b', 'Batch deletion did not remove only the selected label');
  assert(d.getElementById('batch-delete-selected').disabled, 'Batch selection was not reset after deletion');

  const claimCopies = [
    { id: 'claim-a', orderId: 'M-100', version: 1 },
    { id: 'claim-b', orderId: 'M-200', version: 1 }
  ];
  const rowA = {
    id: 'm-a', oid: 'M-100', qty: 1, copies: 1, cod: 3000, ship: 500, pay: 'COD', done: false,
    addedAt: '2026-08-15T08:00:00.000Z', deliverAt: '2026-08-16', deliverTime: '10:00',
    rec: { name: 'Manifest Alpha', phone: '0340000011', area: 'A', address: 'Lot MA', note: '' }
  };
  const rowB = {
    id: 'm-b', oid: 'M-200', qty: 1, copies: 1, cod: 4000, ship: 600, pay: 'COD', done: false,
    addedAt: '2026-08-15T08:10:00.000Z', deliverAt: '2026-08-16', deliverTime: '11:00',
    rec: { name: 'Manifest Beta', phone: '0340000012', area: 'B', address: 'Lot MB', note: '' }
  };
  w.state.manifest = [rowA, rowB];
  w.state.labelVault = JSON.parse(JSON.stringify(claimCopies));
  w.renderManifest();
  assert(d.getElementById('delete-selected-labels'), 'Manifest selected-label deletion control is missing');
  w.setManifestSelected('m-b', true);
  assert(d.getElementById('delete-selected-labels').textContent.includes('(1)'), 'Manifest selected-label count did not update');

  confirmResult = false;
  w.deleteSelectedManifestLabels();
  assert(w.state.manifest.length === 2, 'Cancelled Manifest deletion removed a label');
  assert(confirmations.at(-1).includes('M-200') && confirmations.at(-1).includes('Manifest Beta'),
    'Manifest deletion confirmation did not identify exact order and customer');

  confirmResult = true;
  w.deleteSelectedManifestLabels();
  assert(w.state.manifest.length === 1 && w.state.manifest[0].id === 'm-a', 'Manifest deletion did not remove only the selected label');
  assert(JSON.stringify(w.state.labelVault) === JSON.stringify(claimCopies), 'Manifest deletion changed permanent Claims Vault copies');
  assert(w.localStorage.getItem('P1.labels') && JSON.parse(w.localStorage.getItem('P1.labels')).length === 2,
    'Permanent Claims Vault copies were not retained in storage');

  w.removeRow('m-a');
  assert(w.state.manifest.length === 0, 'Individual manifest Delete Label did not remove its selected row');
  assert(confirmations.at(-1).includes('M-100') && confirmations.at(-1).includes('Manifest Alpha'),
    'Individual manifest deletion confirmation was not exact');
  assert(JSON.stringify(w.state.labelVault) === JSON.stringify(claimCopies), 'Individual manifest deletion changed permanent claim copies');

  assert(!d.getElementById('fatal').textContent, `Fatal UI error: ${d.getElementById('fatal').textContent}`);
  assert(!jsdomErrors.length, `jsdom errors: ${jsdomErrors.join('; ')}`);
  console.log(JSON.stringify({
    ok: true,
    initialRoute: 'home',
    phoneRoutes: routes.map(item => item.route),
    operationsActions: true,
    exactBatchDeletion: true,
    exactManifestDeletion: true,
    cancellationSafe: true,
    claimsVaultRetained: true
  }, null, 2));
  dom.window.close();
})().catch(error => {
  console.error(error.stack || error);
  process.exit(1);
});
