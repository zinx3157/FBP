package mg.labelonzeway.app;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONArray;

import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

@CapacitorPlugin(name = "POS80Printer")
public class POS80PrinterPlugin extends Plugin {
    private static final int DEFAULT_PORT = 9100;
    private static final int CONNECT_TIMEOUT_MS = 8_000;
    private static final int WRITE_TIMEOUT_MS = 45_000;
    private static final int DISCOVERY_TIMEOUT_MS = 550;
    private static final int DISCOVERY_TOTAL_TIMEOUT_MS = 20_000;
    private static final int MAX_PAYLOAD_BYTES = 64 * 1024 * 1024;
    private static final int MAXIMUM_DISCOVERY_NETWORKS = 4;

    private final AtomicInteger discoveryGeneration = new AtomicInteger(0);
    private final AtomicReference<ExecutorService> activeDiscovery = new AtomicReference<>();

    @PluginMethod
    public void health(PluginCall call) {
        new Thread(() -> {
            try {
                String host = call.getString("printer_ip", "");
                Integer requestedPort = call.getInt("printer_port", DEFAULT_PORT);
                int port = requestedPort == null ? DEFAULT_PORT : requestedPort;
                InetSocketAddress target = ensurePrivateTarget(host, port);
                try (Socket socket = new Socket()) {
                    socket.connect(target, CONNECT_TIMEOUT_MS);
                }
                JSObject result = new JSObject();
                result.put("ok", true);
                result.put("printer_ok", true);
                result.put("printer_ip", target.getAddress().getHostAddress());
                result.put("printer_port", port);
                resolve(call, result);
            } catch (Exception error) {
                reject(call, messageFor(error));
            }
        }, "POS80-health").start();
    }

    @PluginMethod
    public void print(PluginCall call) {
        final byte[] payload;
        try {
            String encoded = call.getString("data", "");
            if (encoded.isEmpty()) throw new IllegalArgumentException("The ESC/POS print job is empty");
            payload = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT);
            if (payload.length == 0 || payload.length > MAX_PAYLOAD_BYTES) {
                throw new IllegalArgumentException("The ESC/POS print job is empty or larger than 64 MB");
            }
        } catch (Exception error) {
            call.reject(error.getMessage());
            return;
        }

        new Thread(() -> {
            try {
                String host = call.getString("printer_ip", "");
                Integer requestedPort = call.getInt("printer_port", DEFAULT_PORT);
                int port = requestedPort == null ? DEFAULT_PORT : requestedPort;
                InetSocketAddress target = ensurePrivateTarget(host, port);
                try (Socket socket = new Socket()) {
                    socket.connect(target, CONNECT_TIMEOUT_MS);
                    socket.setTcpNoDelay(true);
                    OutputStream output = socket.getOutputStream();
                    AtomicReference<Exception> writeFailure = new AtomicReference<>();
                    Thread writer = new Thread(() -> {
                        try {
                            output.write(payload);
                            output.flush();
                            try { socket.shutdownOutput(); } catch (Exception ignored) {}
                        } catch (Exception error) { writeFailure.set(error); }
                    }, "POS80-writer");
                    writer.start();
                    writer.join(WRITE_TIMEOUT_MS);
                    if (writer.isAlive()) {
                        try { socket.close(); } catch (Exception ignored) {}
                        writer.interrupt();
                        throw new SocketTimeoutException("Printer did not accept the job within 45 seconds");
                    }
                    if (writeFailure.get() != null) throw writeFailure.get();
                }
                JSObject result = new JSObject();
                result.put("ok", true);
                result.put("bytes_sent", payload.length);
                result.put("printer_ip", target.getAddress().getHostAddress());
                result.put("printer_port", port);
                resolve(call, result);
            } catch (Exception error) {
                reject(call, messageFor(error));
            }
        }, "POS80-print").start();
    }

    /**
     * Finds reachable raw-TCP printers on port 9100 (or the selected manual port).
     * Discovery scans only private/link-local /24 networks attached to Wi-Fi,
     * Ethernet, or hotspot-like interfaces. Mobile-data interfaces are excluded.
     */
    @PluginMethod
    public void discover(PluginCall call) {
        Integer requestedPort = call.getInt("printer_port");
        final int port = requestedPort == null ? DEFAULT_PORT : requestedPort;
        final String preferredRaw = call.getString("preferred_ip");
        final String preferred = preferredRaw == null ? "" : preferredRaw.trim();

        if (port < 1 || port > 65535) {
            call.reject("Printer port must be between 1 and 65535");
            return;
        }

        final int generation = discoveryGeneration.incrementAndGet();
        Thread worker = new Thread(() -> runDiscovery(call, generation, port, preferred), "POS80-printer-discovery");
        worker.setDaemon(true);
        worker.start();
    }

    @PluginMethod
    public void cancelDiscovery(PluginCall call) {
        discoveryGeneration.incrementAndGet();
        ExecutorService discovery = activeDiscovery.getAndSet(null);
        if (discovery != null) discovery.shutdownNow();
        JSObject result = new JSObject();
        result.put("ok", true);
        result.put("cancelled", true);
        call.resolve(result);
    }

    private void runDiscovery(PluginCall call, int generation, int port, String preferred) {
        long started = System.currentTimeMillis();
        ExecutorService pool = null;
        try {
            LinkedHashSet<String> localAddresses = new LinkedHashSet<>();
            LinkedHashSet<String> prefixes = localDiscoveryPrefixes(localAddresses);
            JSONArray networkArray = new JSONArray();
            for (String prefix : prefixes) {
                networkArray.put(prefix + "0/24");
            }

            LinkedHashSet<String> candidates = new LinkedHashSet<>();
            if (isPrivateIpv4Literal(preferred)) {
                candidates.add(preferred);
            }
            for (String prefix : prefixes) {
                // POS80C defaults and common static-printer/gateway addresses first.
                candidates.add(prefix + "173");
                candidates.add(prefix + "100");
                candidates.add(prefix + "200");
                candidates.add(prefix + "2");
                candidates.add(prefix + "1");
                for (int host = 1; host <= 254; host++) {
                    candidates.add(prefix + host);
                }
            }
            candidates.removeAll(localAddresses);

            if (generation != discoveryGeneration.get()) {
                resolveDiscovery(call, true, port, networkArray, new ArrayList<>(), 0, started);
                return;
            }

            int workers = Math.max(8, Math.min(40, candidates.size()));
            pool = Executors.newFixedThreadPool(workers);
            activeDiscovery.set(pool);
            CompletionService<ProbeResult> completion = new ExecutorCompletionService<>(pool);
            int submitted = 0;
            for (String ip : candidates) {
                final String candidate = ip;
                completion.submit(() -> probe(candidate, port));
                submitted++;
            }

            List<ProbeResult> found = new ArrayList<>();
            int completed = 0;
            long deadline = started + DISCOVERY_TOTAL_TIMEOUT_MS;
            while (completed < submitted && generation == discoveryGeneration.get() && System.currentTimeMillis() < deadline) {
                Future<ProbeResult> future = completion.poll(300, TimeUnit.MILLISECONDS);
                if (future == null) {
                    continue;
                }
                completed++;
                try {
                    ProbeResult result = future.get();
                    if (result.reachable) {
                        found.add(result);
                    }
                } catch (Exception ignored) {
                    // A failed candidate is expected during a subnet scan.
                }
            }

            boolean cancelled = generation != discoveryGeneration.get();
            if (pool != null) {
                pool.shutdownNow();
                activeDiscovery.compareAndSet(pool, null);
            }
            Collections.sort(found, (left, right) -> {
                if (left.ip.equals(preferred) && !right.ip.equals(preferred)) return -1;
                if (right.ip.equals(preferred) && !left.ip.equals(preferred)) return 1;
                return compareIpv4(left.ip, right.ip);
            });
            resolveDiscovery(call, cancelled, port, networkArray, found, completed, started);
        } catch (Exception exception) {
            if (pool != null) {
                pool.shutdownNow();
                activeDiscovery.compareAndSet(pool, null);
            }
            call.reject("Printer discovery failed: " + messageFor(exception), exception);
        }
    }

    private void resolveDiscovery(
        PluginCall call,
        boolean cancelled,
        int port,
        JSONArray networks,
        List<ProbeResult> found,
        int scanned,
        long started
    ) {
        JSONArray printers = new JSONArray();
        for (ProbeResult printer : found) {
            JSObject item = new JSObject();
            item.put("ip", printer.ip);
            item.put("port", port);
            item.put("connect_ms", printer.elapsedMs);
            printers.put(item);
        }
        JSObject result = new JSObject();
        result.put("ok", !cancelled);
        result.put("cancelled", cancelled);
        result.put("printer_port", port);
        result.put("printers", printers);
        result.put("networks", networks);
        result.put("scanned", scanned);
        result.put("elapsed_ms", System.currentTimeMillis() - started);
        call.resolve(result);
    }

    private ProbeResult probe(String ip, int port) {
        long started = System.currentTimeMillis();
        try {
            InetSocketAddress target = ensurePrivateTarget(ip, port);
            try (Socket socket = new Socket()) {
                socket.connect(target, DISCOVERY_TIMEOUT_MS);
            }
            return new ProbeResult(ip, true, System.currentTimeMillis() - started);
        } catch (Exception ignored) {
            return new ProbeResult(ip, false, System.currentTimeMillis() - started);
        }
    }

    private LinkedHashSet<String> localDiscoveryPrefixes(Set<String> localAddresses) throws Exception {
        LinkedHashSet<String> prefixes = new LinkedHashSet<>();
        Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
        if (interfaces == null) return prefixes;

        while (interfaces.hasMoreElements() && prefixes.size() < MAXIMUM_DISCOVERY_NETWORKS) {
            NetworkInterface networkInterface = interfaces.nextElement();
            String name = networkInterface.getName() == null ? "" : networkInterface.getName().toLowerCase(Locale.US);
            if (!networkInterface.isUp() || networkInterface.isLoopback() || networkInterface.isVirtual() || isMobileDataInterface(name)) {
                continue;
            }
            Enumeration<InetAddress> addresses = networkInterface.getInetAddresses();
            while (addresses.hasMoreElements() && prefixes.size() < MAXIMUM_DISCOVERY_NETWORKS) {
                InetAddress address = addresses.nextElement();
                if (!(address instanceof Inet4Address) || address.isLoopbackAddress()) continue;
                if (!address.isSiteLocalAddress() && !address.isLinkLocalAddress()) continue;
                String ip = address.getHostAddress();
                localAddresses.add(ip);
                int lastDot = ip.lastIndexOf('.');
                if (lastDot > 0) prefixes.add(ip.substring(0, lastDot + 1));
            }
        }
        return prefixes;
    }

    private boolean isMobileDataInterface(String name) {
        return name.startsWith("rmnet") || name.startsWith("ccmni") || name.startsWith("pdp") ||
            name.startsWith("wwan") || name.startsWith("cell") || name.startsWith("v4-rmnet") ||
            name.startsWith("v6-rmnet");
    }

    private boolean isPrivateIpv4Literal(String host) {
        if (host == null || host.isEmpty() || !host.matches("^(?:\\d{1,3}\\.){3}\\d{1,3}$")) return false;
        try {
            InetAddress address = InetAddress.getByName(host);
            return address instanceof Inet4Address && (address.isSiteLocalAddress() || address.isLinkLocalAddress());
        } catch (Exception ignored) {
            return false;
        }
    }

    private int compareIpv4(String left, String right) {
        String[] a = left.split("\\.");
        String[] b = right.split("\\.");
        for (int index = 0; index < 4; index++) {
            int difference = Integer.parseInt(a[index]) - Integer.parseInt(b[index]);
            if (difference != 0) return difference;
        }
        return 0;
    }

    private InetSocketAddress ensurePrivateTarget(String host, int port) throws Exception {
        if (host == null || host.trim().isEmpty()) {
            throw new IllegalArgumentException("Enter the POS80C printer IP address");
        }
        if (port < 1 || port > 65535) {
            throw new IllegalArgumentException("Printer port must be between 1 and 65535");
        }

        InetAddress[] addresses = InetAddress.getAllByName(host.trim());
        for (InetAddress address : addresses) {
            if (address.isSiteLocalAddress() || address.isLinkLocalAddress() || address.isLoopbackAddress()) {
                return new InetSocketAddress(address, port);
            }
        }
        throw new IllegalArgumentException("For safety, direct printing only connects to private/local printer addresses");
    }

    private String messageFor(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.trim().isEmpty() ? exception.getClass().getSimpleName() : message;
    }


    private void resolve(PluginCall call, JSObject result) {
        getActivity().runOnUiThread(() -> call.resolve(result));
    }

    private void reject(PluginCall call, String message) {
        getActivity().runOnUiThread(() -> call.reject(message));
    }
    private static final class ProbeResult {
        final String ip;
        final boolean reachable;
        final long elapsedMs;

        ProbeResult(String ip, boolean reachable, long elapsedMs) {
            this.ip = ip;
            this.reachable = reachable;
            this.elapsedMs = elapsedMs;
        }
    }
}
