package mg.labelonzeway.app;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(POS80PrinterPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
