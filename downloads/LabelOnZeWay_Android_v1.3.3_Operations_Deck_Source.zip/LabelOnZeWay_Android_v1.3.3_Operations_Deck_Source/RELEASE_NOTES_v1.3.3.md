# LabelOnZeWay Android v1.3.3 — Operations Deck

- Applies Google Stitch Proposal A to the canonical production workflow rather than replacing it with a demo.
- Adds a live Home operations dashboard and a compact More control center.
- Uses five explicit phone destinations: Home, New Label, Batch, Manifest, and More.
- Adds per-label Batch selection and exact, cancellable selected-label deletion.
- Adds count-aware Manifest selected-label deletion with exact order/customer confirmation.
- Manifest deletion retains permanent synchronized Claims Vault copies.
- Keeps New Label, copies 1–20, customer coordination, reports, archive, payments, backup, Deep Rescue, staff cloud sync, and company profiles.
- Keeps Android system printing and native direct TCP ESC/POS printing with automatic bounded/cancellable POS80C detection.
- Keeps zero avoidable inter-label feed and one configured cut after each physical label.

Version: `1.3.3` · Android version code: `8`.

Install the APK over the existing LabelOnZeWay app. Do not uninstall first; uninstalling removes device-local data. Export customers and create a full backup before updating.
