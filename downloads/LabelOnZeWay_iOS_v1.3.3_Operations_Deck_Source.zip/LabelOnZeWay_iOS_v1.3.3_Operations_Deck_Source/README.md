# LabelOnZeWay for iOS — Xcode Installation and POS80C Test

This is the Xcode-ready iOS source for **LabelOnZeWay 1.3.3**.

It keeps the complete LabelOnZeWay workflow and supports both:

- **Direct POS80C printing:** raw TCP/ESC-POS from the iPhone to `192.168.100.173:9100`; no Mac, HTTP gateway, or third-party print app is needed during normal printing.
- **iPhone System Print:** Apple's print sheet/AirPrint remains available as an alternative.

The direct-print defaults match the Android version already accepted on the physical POS80C: 576-dot raster output, compact consecutive labels, zero added feed, partial cut after every label.

## Important build status

The source project is complete and prepared for Xcode. Version 1.3.3 applies Google Stitch Proposal A — Operations Deck and includes the permanent versioned Label Claims Vault, SHIPDESK/LabelOnZeWay claim synchronization, the current UIKit completion-handler name, secure authentication/cloud sync, historical address-book recovery/export, and bounded cancellable POS80C discovery. This package does **not** contain an IPA because Apple requires the final app to be compiled and signed on macOS with your Apple ID/team. The included Linux-side tests passed, but the first successful Xcode build and physical iPhone/POS80C acceptance test are still required.

## Requirements

- A Mac capable of running **Xcode 16.0 or newer**
- An iPhone/iPad running **iOS 14 or newer**
- Node.js **20 or newer**
- CocoaPods
- An Apple ID added to Xcode
- The Mac needs internet access for the one-time dependency installation
- The iPhone and POS80C must be on the same non-guest Wi-Fi network for direct printing

Capacitor is pinned to version `7.6.8`. The app bundle ID is `mg.labelonzeway.app`.

## 1. Prepare the Mac

Install Xcode from the Mac App Store, open it once, and accept its license. Then open Terminal and verify the command-line tools:

```bash
xcode-select -p
```

If that command fails, run:

```bash
xcode-select --install
```

Install Node.js 20+ from <https://nodejs.org/>. If CocoaPods is not installed and Homebrew is available, run:

```bash
brew install cocoapods
```

Verify the tools:

```bash
node --version
pod --version
xcodebuild -version
```

## 2. Prepare and open the project

### Easy method

1. Unzip this package on the Mac.
2. Control-click `Prepare_LabelOnZeWay_iOS.command` and choose **Open**.
3. macOS may ask you to confirm the first launch; choose **Open** again.
4. The script installs the pinned packages, runs the Capacitor iOS sync, installs CocoaPods, and opens the workspace.

### Terminal method

From the unzipped project folder:

```bash
npm ci
npm run bridge
npx cap sync ios
open ios/App/App.xcworkspace
```

Always open **`App.xcworkspace`**, not `App.xcodeproj`, after CocoaPods has been installed.

## 3. Sign and install on the iPhone

1. Connect the unlocked iPhone to the Mac with USB.
2. On the iPhone, tap **Trust This Computer** if asked.
3. In Xcode, select the blue **App** project, then the **App** target.
4. Open **Signing & Capabilities**.
5. Enable **Automatically manage signing**.
6. Select your Apple ID/team in **Team**.
7. Keep the bundle identifier `mg.labelonzeway.app` unless Xcode says it is unavailable for your team. If necessary for a private test, change it to a unique value such as `mg.labelonzeway.app.yourname`.
8. At the top of Xcode, select the connected iPhone as the run destination.
9. Press the triangular **Run** button.

On iOS 16 or newer, the phone may require **Settings → Privacy & Security → Developer Mode**, followed by a restart. A free Personal Team can install a test build, but Apple normally requires it to be re-signed/reinstalled after about seven days. A paid Apple Developer membership avoids that short test-signing period.

If iOS blocks the first launch, open **Settings → General → VPN & Device Management**, select the developer profile, and trust it.


## Historical address-book recovery and cloud sync

Version 1.3.3 adds **Deep Rescue** and **Export CSV**. Deep Rescue uses a bounded scan across nested address books, manifests, archives, retained label copies, cloud queues, and legacy customer/recipient structures. It shows source/count details before merge, retains current customers, conservatively deduplicates/enriches, does not mutate source data, and automatically creates a rescue CSV. Install this update over the existing app without deleting it so isolated native storage is preserved.

Separate authorized staff logins can synchronize safe business workflow data through one Supabase company workspace. Password recovery, Set New Password, and signed-in Change Password are included. Printer settings and active print queues remain local.

## 4. First POS80C test

Before testing, confirm the POS80C is powered on and still has IP address `192.168.100.173`.

1. Connect the iPhone to the same Wi-Fi network as the POS80C. Do not use guest Wi-Fi or mobile data.
2. Open **LabelOnZeWay**.
3. When iOS asks whether LabelOnZeWay may find/connect to devices on the local network, tap **Allow**.
4. Open **Settings → Printer** in the app.
5. Confirm:
   - Print mode: **Direct Wi-Fi ESC/POS from this iPhone**
   - Printer IP: `192.168.100.173`
   - Port: `9100`
   - Width: `576` dots
   - Added feed: `0`
   - Cut: **Partial**
   - Cut after each label: enabled
6. Tap **Auto-detect POS80C**. Allow the bounded local-network scan to finish, or verify that Cancel stops it. Choose the printer if more than one raw-TCP device is found.
7. Tap **Test Connection**. It should report that the iPhone connected directly.
8. Tap the cut test only when paper is loaded; it sends a small real ESC/POS job and operates the cutter.
9. Create or select two labels and print them together.
10. Confirm both labels are compact, have no unwanted blank gap, and are cut separately.

The direct socket has an 8-second connection timeout, a 45-second bounded write, and a 64 MB maximum job size.

## 5. Test iPhone System Print/AirPrint

1. In **Settings → Printer**, choose **iPhone system print · AirPrint**.
2. Print a label, manifest, or report.
3. Confirm Apple's native print sheet opens.

The POS80C itself must support AirPrint, or an AirPrint-compatible print server must be available, to select it in Apple's print sheet. Direct ESC/POS mode does not need AirPrint.

## Troubleshooting

### Local Network permission was denied

Open one of these locations, depending on the iOS version:

- **Settings → Apps → LabelOnZeWay → Local Network**
- **Settings → Privacy & Security → Local Network → LabelOnZeWay**

Enable access, return to the app, and run **Test Connection** again.

### “Cannot reach POS80C”

- Confirm the iPhone is using Wi-Fi rather than mobile data.
- Confirm the iPhone and printer are on the same LAN/VLAN.
- Avoid guest Wi-Fi, client isolation, VPNs, and Private Relay for this test.
- Confirm the printer IP is `192.168.100.173` and raw TCP port `9100` is enabled.
- Verify another device has not changed the printer's DHCP address.

### Xcode says CocoaPods or the sandbox is not in sync

Close Xcode, then run from this project folder:

```bash
npm ci
npx cap sync ios
cd ios/App
pod install
open App.xcworkspace
```

### Xcode reports “No such module Capacitor”

Open `ios/App/App.xcworkspace`, not `App.xcodeproj`. If needed, rerun `npx cap sync ios` first.

### Signing or bundle-identifier error

Choose your team under **Signing & Capabilities**. If the bundle ID is unavailable, use a unique bundle ID for the private test. Signing is controlled only by your Apple account; no signing credentials are included in this package.

### Recover historical address books before clearing data

Do not delete/reinstall the app or clear Safari/Chrome website data while historical records remain only on that device. In the browser/profile where the old SHIPDESK records are visible, open the production LabelOnZeWay web route, choose **Deep Rescue**, review each source/count, confirm the merge, and keep the automatic rescue CSV plus a full Backup. For native-app data, install this Xcode build over the existing app without deleting it.

### The app was removed or reinstalled

The app is local-first. Authorized business records can synchronize through the shared Supabase workspace, but printer settings and active/deferred queues stay device-local. Before deleting/reinstalling, run Export CSV and Backup and keep the files in Files, iCloud Drive, or on the Mac.

## Updating web files later

After changing files under `www/` or `src/native-bridge.js`, run:

```bash
npm run bridge
npx cap sync ios
```

The Swift printer plugin is in:

- `ios/App/App/POS80PrinterPlugin.swift`
- `ios/App/App/LabelOnZeWayViewController.swift`

## Test records

See `TEST_RESULTS.md` for completed automated/static checks and the remaining physical iPhone acceptance checklist.
