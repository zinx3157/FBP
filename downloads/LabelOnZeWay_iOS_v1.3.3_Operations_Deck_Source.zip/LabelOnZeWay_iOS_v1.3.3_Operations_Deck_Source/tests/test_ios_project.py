#!/usr/bin/env python3
"""Static integrity checks that can run without macOS/Xcode."""

import json
import plistlib
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks = []


def check(name, condition, detail=""):
    if not condition:
        raise AssertionError(f"{name}: {detail or 'failed'}")
    checks.append(name)


def png_info(path):
    data = path.read_bytes()[:33]
    check(f"PNG signature: {path.name}", data[:8] == b"\x89PNG\r\n\x1a\n")
    width, height, bit_depth, colour_type = struct.unpack(">IIBB", data[16:26])
    return width, height, bit_depth, colour_type


package = json.loads((ROOT / "package.json").read_text())
config = json.loads((ROOT / "capacitor.config.json").read_text())
info = plistlib.loads((ROOT / "ios/App/App/Info.plist").read_bytes())
plugin = (ROOT / "ios/App/App/POS80PrinterPlugin.swift").read_text()
controller = (ROOT / "ios/App/App/LabelOnZeWayViewController.swift").read_text()
storyboard = (ROOT / "ios/App/App/Base.lproj/Main.storyboard").read_text()
project = (ROOT / "ios/App/App.xcodeproj/project.pbxproj").read_text()
web = (ROOT / "www/index.html").read_bytes()
public_web = (ROOT / "ios/App/App/public/index.html").read_bytes()

check("Package version", package["version"] == "1.3.3")
check("Capacitor 7.6.8 core", package["dependencies"]["@capacitor/core"] == "7.6.8")
check("Capacitor 7.6.8 iOS", package["dependencies"]["@capacitor/ios"] == "7.6.8")
check("Bundle ID", config["appId"] == "mg.labelonzeway.app")
check("iOS build number", project.count("CURRENT_PROJECT_VERSION = 8;") == 2)
check("iOS marketing version", project.count("MARKETING_VERSION = 1.3.3;") == 2)
check("App name", config["appName"] == "LabelOnZeWay")
check("Local-network permission", bool(info.get("NSLocalNetworkUsageDescription")))
check("Camera permission", bool(info.get("NSCameraUsageDescription")))
check("Photo-library permission", bool(info.get("NSPhotoLibraryUsageDescription")))
check("Raw TCP Network.framework", "NWConnection(" in plugin and "NWParameters.tcp" in plugin)
check("Health bridge method", 'CAPPluginMethod(name: "health"' in plugin)
check("Print bridge method", 'CAPPluginMethod(name: "print"' in plugin)
check("iOS System Print bridge method", 'CAPPluginMethod(name: "systemPrint"' in plugin)
check("AirPrint controller", "UIPrintInteractionController.shared" in plugin)
check("Current UIKit completion-handler name", "UIPrintInteractionController.CompletionHandler" in plugin)
check("8-second connection bound", "connectTimeout: TimeInterval = 8" in plugin)
check("45-second write bound", "writeTimeout: TimeInterval = 45" in plugin)
check("64 MB print bound", "64 * 1024 * 1024" in plugin)
check("Private IPv4 validation", "isPrivateIPv4" in plugin)
check("Plugin registration", "registerPluginInstance(POS80PrinterPlugin())" in controller)
check("Custom bridge controller", 'customClass="LabelOnZeWayViewController"' in storyboard)
check("Plugin file in Xcode project", project.count("POS80PrinterPlugin.swift") >= 4)
check("Controller file in Xcode project", project.count("LabelOnZeWayViewController.swift") >= 4)
check("Swift files in Sources phase", "POS80PrinterPlugin.swift in Sources" in project and "LabelOnZeWayViewController.swift in Sources" in project)
check("iOS deployment target 14", "IPHONEOS_DEPLOYMENT_TARGET = 14.0" in project)
check("Xcode bundle ID", "PRODUCT_BUNDLE_IDENTIFIER = mg.labelonzeway.app" in project)
check("Public web copy current", web == public_web)
check(
    "Public native bridge current",
    (ROOT / "www/native-bridge.bundle.js").read_bytes()
    == (ROOT / "ios/App/App/public/native-bridge.bundle.js").read_bytes(),
)
html = web.decode("utf-8")
check("Adaptive direct iOS UI", "Direct ESC/POS · from this" in html and "iPhone/iPad" in html)
check("AirPrint UI", "iPhone / iPad system print · AirPrint" in html)
check("Discovery bridge method", 'CAPPluginMethod(name: "discover"' in plugin and 'CAPPluginMethod(name: "cancelDiscovery"' in plugin)
check("Bounded native discovery", "private final class PrinterDiscovery" in plugin and "maximumNetworks = 4" in plugin)
check("Cloud client copied", (ROOT / "www/cloud-sync.js").read_bytes() == (ROOT / "ios/App/App/public/cloud-sync.js").read_bytes())
check("Accepted printer default", "printerIp:'192.168.100.173'" in html and "printerPort:9100" in html)
check("Accepted zero feed default", "printerFeed:0" in html)
check("Accepted partial cut default", "printerCut:'partial'" in html and "cutEach:true" in html)

icon = ROOT / "ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png"
w, h, depth, colour = png_info(icon)
check("Branded app-icon dimensions", (w, h) == (1024, 1024))
check("App icon has no alpha channel", depth == 8 and colour == 2)

for name in ("splash-2732x2732.png", "splash-2732x2732-1.png", "splash-2732x2732-2.png"):
    splash = ROOT / "ios/App/App/Assets.xcassets/Splash.imageset" / name
    w, h, depth, colour = png_info(splash)
    check(f"Splash dimensions: {name}", (w, h) == (2732, 2732))
    check(f"Splash RGB: {name}", depth == 8 and colour == 2)

print(json.dumps({"ok": True, "checks": len(checks), "results": checks}, indent=2))
