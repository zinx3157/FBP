# LabelOnZeWay iOS 1.3.1 — Test Record

**Validation date:** 2026-08-15  
**Bundle ID:** `mg.labelonzeway.app`  
**Marketing/build version:** `1.3.1 (4)`  
**Capacitor:** `7.6.8`  
**Minimum iOS:** `14.0`  
**Default POS80C target:** `192.168.100.173:9100`

## Passed in the Linux preparation environment

### Web/native workflow suites

`npm test` passed after final Capacitor synchronization.

- Native health calls: 1
- Native print calls: 1
- Labels in simulated batch: 2
- ESC/POS payload: 84,125 bytes
- Raster commands: 2
- Partial-cut commands: 2
- Added-feed commands: 0
- System Print alternative: present
- Application buttons exercised: 83
- Failed actions: 0
- Missing action handlers: 0
- Fatal/JSDOM errors: none

The synchronized app includes New Label, visible Batch Delete Label, copies 1–20, Back/Cancel, compact Manifest, company profiles, reports/archives, secure authentication, cloud sync, historical-book recovery, and CSV export.

### Historical address-book recovery/export

Dedicated native Deep Rescue coverage passed for five nested source classes, source/count preview, confirmation cancellation, settings exclusion, source immutability, conservative merge, active-book persistence, and automatic rescue CSV. Deep Rescue retains current customers and does not rewrite historical sources.

### iOS project integrity

`python3 tests/test_ios_project.py` passed **all 46 checks**.

Verified areas include:

- Capacitor core/iOS 7.6.8, bundle ID, app name, deployment target, icons, and splash resources;
- Local Network, camera, and photo-library permission descriptions;
- raw TCP `Network.framework` printing and UIKit/AirPrint system printing;
- current `UIPrintInteractionController.CompletionHandler` name;
- 8-second connect, 45-second write, and 64 MB job bounds;
- private IPv4 validation;
- native `health`, `print`, `systemPrint`, `discover`, and `cancelDiscovery` methods;
- bounded cancellable discovery: at most four private `/24` networks, 40 concurrent probes, and 0.55-second host timeout;
- custom bridge registration and Swift files in the Xcode Sources phase;
- synchronized current web/native bridge/cloud assets;
- accepted zero-feed and partial-cut defaults.

### Capacitor synchronization

- `npx cap copy ios` and `npx cap sync ios` completed.
- Linux correctly skipped CocoaPods and the Xcode clean step because those Mac tools are unavailable.
- `AppDelegate.swift`, `LabelOnZeWayViewController.swift`, and `POS80PrinterPlugin.swift` remained byte-identical through synchronization.

### Dependency audit

- Full npm development-tool audit: 9 transitive findings (2 moderate, 6 high, 1 critical), reached through the Capacitor asset/build toolchain (`tar`, `sharp`, `minimatch`, `uuid`, and related tooling).
- Production/runtime audit (`npm audit --omit=dev`): **0 findings**.
- No breaking `npm audit fix --force` was applied. Reassess the development tools when compatible upstream Capacitor/asset updates are available.

## Not yet claimed

Linux cannot compile/sign an iOS app or produce a trustworthy IPA. Complete these steps on the user's Mac/iPhone:

- install CocoaPods and run `npx cap sync ios`;
- open `ios/App/App.xcworkspace` in Xcode;
- compile/link Swift with Xcode;
- sign with the user's Apple ID/team;
- install and launch on the physical iPhone;
- allow Local Network access;
- test discovery and discovery cancellation on the real LAN;
- verify direct POS80C output has no avoidable gap and one cut per label;
- verify Apple's System Print/AirPrint sheet;
- validate real password-recovery email callback and shared-workspace synchronization.

## Physical iPhone acceptance checklist

- [ ] Xcode workspace build succeeds
- [ ] App installs and launches on iPhone
- [ ] Local Network access is allowed
- [ ] Auto-detect finds the intended POS80C
- [ ] Cancel stops an active discovery scan
- [ ] Test Connection reaches the selected printer on port `9100`
- [ ] Cut test prints and cuts
- [ ] Consecutive labels have no unintended blank gap
- [ ] Each physical label copy is cut separately
- [ ] Apple's System Print sheet opens in AirPrint mode
- [ ] Shared-workspace sync works with authorized staff logins
- [ ] Backup/export is completed before any uninstall, reinstall, or data clearing
