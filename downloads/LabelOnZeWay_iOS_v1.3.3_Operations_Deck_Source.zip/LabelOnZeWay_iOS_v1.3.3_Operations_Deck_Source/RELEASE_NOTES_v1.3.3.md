# LabelOnZeWay iOS v1.3.3 — Operations Deck

- Applies Google Stitch Proposal A to the canonical iOS production workflow.
- Adds Home and More, with five explicit phone destinations and compact safe-area-aware controls.
- Adds exact, cancellable selected-label deletion to Batch and Manifest.
- Retains permanent synchronized Claims Vault copies when active-manifest labels are deleted.
- Keeps the complete Android-equivalent workflow, cloud/offline behavior, company profiles, reports, archive, backup, and Deep Rescue.
- Keeps iOS system printing/AirPrint and native direct TCP ESC/POS printing with bounded/cancellable automatic POS80C detection.
- Keeps zero avoidable inter-label feed and one configured cut after each physical label.

Marketing version: `1.3.3` · build: `8`.

The Xcode project must still be compiled, signed, installed, and physically tested from macOS/Xcode. Install over the existing app; do not delete it before backup and Deep Rescue verification.
