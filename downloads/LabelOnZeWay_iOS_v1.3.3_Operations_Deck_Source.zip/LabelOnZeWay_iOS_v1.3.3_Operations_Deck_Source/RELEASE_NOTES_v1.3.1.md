# LabelOnZeWay iOS v1.3.1 — recovery update

Date: 2026-08-15

- Adds bounded, non-destructive **Deep Rescue** across nested native localStorage structures, with source/count preview and automatic rescue CSV.
- Preserves current customers and tested historical source values while conservatively deduplicating/enriching.
- Prevents an unexpectedly empty local customer book from creating non-forced mass cloud tombstones; explicit deletion still synchronizes.
- Retains bounded/cancellable POS80C discovery, direct raw-TCP printing, AirPrint/System Print, compact New/Batch/Manifest workflows, copies, Back/Cancel, archives, reports, profiles, and cloud synchronization.

## Update metadata

- Bundle ID: `mg.labelonzeway.app`
- Marketing version: `1.3.1`
- Build: `4`
- Minimum iOS: `14.0`
- Capacitor iOS: `7.6.8`

Build and sign through `ios/App/App.xcworkspace` on the Mac, then install over the existing app. **Do not delete the existing app first** because its isolated native storage may contain the recoverable historical records.

The JavaScript workflow/Deep Rescue suites and all 46 iOS native project/static checks pass. Xcode compilation/signing, in-place installation, real storage recovery, cloud authentication, discovery, AirPrint, and physical POS80C testing remain required.
