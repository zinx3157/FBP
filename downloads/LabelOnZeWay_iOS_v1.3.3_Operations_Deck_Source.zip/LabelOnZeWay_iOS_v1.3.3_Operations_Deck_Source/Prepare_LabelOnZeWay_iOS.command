#!/bin/zsh
set -euo pipefail

cd "$(dirname "$0")"

echo ""
echo "LabelOnZeWay iOS — preparing the Xcode workspace"
echo "Project: $PWD"
echo ""

if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: Node.js 20 or newer is required. Install it from https://nodejs.org/"
  read -r "?Press Return to close..."
  exit 1
fi

if ! command -v pod >/dev/null 2>&1; then
  echo "ERROR: CocoaPods is required. If Homebrew is installed, run:"
  echo "  brew install cocoapods"
  read -r "?Press Return to close..."
  exit 1
fi

echo "Installing the pinned JavaScript/Capacitor dependencies..."
npm ci

echo "Building the native JavaScript bridge and installing iOS pods..."
npm run bridge
npx cap sync ios

echo ""
echo "Preparation complete. Opening the Xcode workspace..."
open ios/App/App.xcworkspace

echo ""
echo "In Xcode: select the App target, choose your Team under Signing & Capabilities,"
echo "select your connected iPhone, and press Run."
read -r "?Press Return to close this window..."
