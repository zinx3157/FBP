import Capacitor
import UIKit

/** Registers the app-local native bridge before the WebView loads. */
@objc(LabelOnZeWayViewController)
class LabelOnZeWayViewController: CAPBridgeViewController {
    override open func capacitorDidLoad() {
        bridge?.registerPluginInstance(POS80PrinterPlugin())
    }
}
