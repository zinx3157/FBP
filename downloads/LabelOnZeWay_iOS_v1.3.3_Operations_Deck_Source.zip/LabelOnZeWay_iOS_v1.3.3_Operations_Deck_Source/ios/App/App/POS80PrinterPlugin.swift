import Capacitor
import Darwin
import Foundation
import Network
import UIKit

/**
 * Sends already-rendered ESC/POS bytes directly from the iPhone/iPad to a
 * private-network printer. JavaScript performs rasterisation and inserts the
 * configured cutter command after every label; this plugin transmits the bytes
 * unchanged over raw TCP.
 *
 * The same bridge also exposes iOS System Print so AirPrint remains available
 * as an alternative to direct POS80C printing.
 */
@objc(POS80PrinterPlugin)
public class POS80PrinterPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "POS80PrinterPlugin"
    public let jsName = "POS80Printer"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "health", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "print", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "systemPrint", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "discover", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "cancelDiscovery", returnType: CAPPluginReturnPromise)
    ]

    private static let connectTimeout: TimeInterval = 8
    private static let writeTimeout: TimeInterval = 45
    private static let maximumJobBytes = 64 * 1024 * 1024
    private var activeDiscovery: PrinterDiscovery?

    @objc public func health(_ call: CAPPluginCall) {
        let target: PrinterTarget
        do {
            target = try readTarget(call)
        } catch {
            call.reject(error.localizedDescription)
            return
        }

        PrinterTCPJob(
            target: target,
            payload: nil,
            connectTimeout: Self.connectTimeout,
            writeTimeout: Self.writeTimeout
        ) { result in
            switch result {
            case .success:
                call.resolve([
                    "ok": true,
                    "printer_ok": true,
                    "printer_ip": target.ip,
                    "printer_port": target.port
                ])
            case .failure(let error):
                call.reject(self.friendlyNetworkError(error, target: target))
            }
        }.start()
    }

    @objc public func print(_ call: CAPPluginCall) {
        let target: PrinterTarget
        let payload: Data
        do {
            target = try readTarget(call)
            guard let encoded = call.getString("data"), !encoded.isEmpty else {
                throw PrinterPluginError.message("The ESC/POS print job is empty")
            }

            // Reject an oversized Base64 value before attempting a large decode.
            let maximumEncodedLength = ((Self.maximumJobBytes + 2) / 3) * 4 + 8
            guard encoded.utf8.count <= maximumEncodedLength,
                  let decoded = Data(base64Encoded: encoded),
                  !decoded.isEmpty,
                  decoded.count <= Self.maximumJobBytes else {
                throw PrinterPluginError.message("The ESC/POS print job is invalid, empty, or larger than 64 MB")
            }
            payload = decoded
        } catch {
            call.reject(error.localizedDescription)
            return
        }

        PrinterTCPJob(
            target: target,
            payload: payload,
            connectTimeout: Self.connectTimeout,
            writeTimeout: Self.writeTimeout
        ) { result in
            switch result {
            case .success(let bytesSent):
                call.resolve([
                    "ok": true,
                    "bytes_sent": bytesSent,
                    "printer_ip": target.ip,
                    "printer_port": target.port
                ])
            case .failure(let error):
                call.reject(self.friendlyNetworkError(error, target: target))
            }
        }.start()
    }

    /** Scans a bounded set of private /24 LANs for a raw TCP printer. */
    @objc public func discover(_ call: CAPPluginCall) {
        let port = call.getInt("printer_port", 9100)
        guard (1...65535).contains(port) else {
            call.reject("Printer port must be between 1 and 65535")
            return
        }
        let preferredIP = (call.getString("preferred_ip") ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        activeDiscovery?.cancel()
        var discovery: PrinterDiscovery!
        discovery = PrinterDiscovery(port: port, preferredIP: preferredIP) { [weak self] printers, networks, cancelled in
            guard let self = self else { return }
            if self.activeDiscovery === discovery {
                self.activeDiscovery = nil
            }
            call.resolve([
                "ok": true,
                "cancelled": cancelled,
                "printers": printers.map { ["ip": $0, "port": port] },
                "networks": networks
            ])
        }
        activeDiscovery = discovery
        discovery.start()
    }

    @objc public func cancelDiscovery(_ call: CAPPluginCall) {
        let discovery = activeDiscovery
        activeDiscovery = nil
        discovery?.cancel()
        call.resolve(["ok": true, "cancelled": discovery != nil])
    }

    /** Presents Apple's print sheet for the current app WebView (AirPrint/PDF). */
    @objc public func systemPrint(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard let webView = self.webView else {
                call.reject("The iOS print view is not available")
                return
            }

            let controller = UIPrintInteractionController.shared
            let information = UIPrintInfo(dictionary: nil)
            information.outputType = .general
            information.jobName = call.getString("title", "LabelOnZeWay")
            controller.printInfo = information
            controller.printFormatter = webView.viewPrintFormatter()
            controller.showsNumberOfCopies = true

            var settled = false
            let completion: UIPrintInteractionController.CompletionHandler = { _, completed, error in
                guard !settled else { return }
                settled = true
                if let error = error {
                    call.reject("iOS System Print failed: \(error.localizedDescription)", nil, error)
                } else {
                    call.resolve(["ok": true, "completed": completed])
                }
            }

            let presented: Bool
            if UIDevice.current.userInterfaceIdiom == .pad {
                presented = controller.present(
                    from: webView.bounds,
                    in: webView,
                    animated: true,
                    completionHandler: completion
                )
            } else {
                presented = controller.present(animated: true, completionHandler: completion)
            }

            if !presented && !settled {
                settled = true
                call.reject("The iOS print sheet could not be opened")
            }
        }
    }

    private func readTarget(_ call: CAPPluginCall) throws -> PrinterTarget {
        let ip = (call.getString("printer_ip") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let port = call.getInt("printer_port", 9100)
        guard Self.isPrivateIPv4(ip) else {
            throw PrinterPluginError.message(
                "Enter a private printer IPv4 address (10.x, 172.16-31.x, or 192.168.x)"
            )
        }
        guard (1...65535).contains(port) else {
            throw PrinterPluginError.message("Printer port must be between 1 and 65535")
        }
        return PrinterTarget(ip: ip, port: port)
    }

    private static func isPrivateIPv4(_ value: String) -> Bool {
        let parts = value.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count == 4 else { return false }

        var octets: [Int] = []
        for part in parts {
            guard !part.isEmpty,
                  part.count <= 3,
                  part.allSatisfy({ $0.isNumber }),
                  let number = Int(part),
                  (0...255).contains(number) else {
                return false
            }
            octets.append(number)
        }

        return octets[0] == 10
            || (octets[0] == 172 && (16...31).contains(octets[1]))
            || (octets[0] == 192 && octets[1] == 168)
            || (octets[0] == 169 && octets[1] == 254)
            || octets[0] == 127
    }

    private func friendlyNetworkError(_ error: Error, target: PrinterTarget) -> String {
        return "Cannot reach POS80C at \(target.ip):\(target.port). Confirm the iPhone is on the printer Wi-Fi, Local Network access is allowed in Settings, and the IP/port are correct. \(error.localizedDescription)"
    }
}

private struct PrinterTarget {
    let ip: String
    let port: Int
}

private enum PrinterPluginError: LocalizedError {
    case message(String)

    var errorDescription: String? {
        switch self {
        case .message(let text): return text
        }
    }
}

/** A bounded private-network scan. It never probes public addresses or an unbounded subnet. */
private final class PrinterDiscovery {
    typealias Completion = (_ printers: [String], _ networks: [String], _ cancelled: Bool) -> Void

    private let port: Int
    private let preferredIP: String
    private let completion: Completion
    private let queue = DispatchQueue(label: "mg.labelonzeway.pos80.discovery")
    private let maximumNetworks = 4
    private let maximumConcurrentProbes = 40
    private let probeTimeout: TimeInterval = 0.55
    private var pending: [String] = []
    private var active: [String: PrinterProbe] = [:]
    private var printers: [String] = []
    private var networks: [String] = []
    private var finished = false

    init(port: Int, preferredIP: String, completion: @escaping Completion) {
        self.port = port
        self.preferredIP = preferredIP
        self.completion = completion
    }

    func start() {
        queue.async {
            guard !self.finished else { return }
            let localIPs = Self.localPrivateIPv4Addresses()
            var prefixes: [String] = []
            if let preferredPrefix = Self.privatePrefix(self.preferredIP) {
                prefixes.append(preferredPrefix)
            }
            for ip in localIPs {
                if let prefix = Self.privatePrefix(ip), !prefixes.contains(prefix) {
                    prefixes.append(prefix)
                }
                if prefixes.count >= self.maximumNetworks { break }
            }
            prefixes = Array(prefixes.prefix(self.maximumNetworks))
            self.networks = prefixes.map { $0 + ".0/24" }

            let localSet = Set(localIPs)
            var candidates: [String] = []
            if Self.privatePrefix(self.preferredIP) != nil, !localSet.contains(self.preferredIP) {
                candidates.append(self.preferredIP)
            }
            let priorityHosts = [173, 100, 200, 1, 2, 10, 20, 50, 99, 101, 150, 201, 254]
            for prefix in prefixes {
                var hosts = priorityHosts
                for host in 1...254 where !hosts.contains(host) { hosts.append(host) }
                for host in hosts {
                    let ip = "\(prefix).\(host)"
                    if !localSet.contains(ip), !candidates.contains(ip) { candidates.append(ip) }
                }
            }
            self.pending = candidates
            self.launchAvailableProbes()
        }
    }

    func cancel() {
        queue.async {
            guard !self.finished else { return }
            let probes = Array(self.active.values)
            self.active.removeAll()
            self.pending.removeAll()
            probes.forEach { $0.cancel() }
            self.finish(cancelled: true)
        }
    }

    private func launchAvailableProbes() {
        guard !finished else { return }
        while active.count < maximumConcurrentProbes, !pending.isEmpty {
            let ip = pending.removeFirst()
            let probe = PrinterProbe(ip: ip, port: port, timeout: probeTimeout)
            active[ip] = probe
            probe.start(queue: queue) { [weak self] reachable in
                guard let self = self, !self.finished else { return }
                self.active.removeValue(forKey: ip)
                if reachable, !self.printers.contains(ip) { self.printers.append(ip) }
                self.launchAvailableProbes()
            }
        }
        if pending.isEmpty, active.isEmpty { finish(cancelled: false) }
    }

    private func finish(cancelled: Bool) {
        guard !finished else { return }
        finished = true
        let sortedPrinters = printers.sorted { Self.ipv4Number($0) < Self.ipv4Number($1) }
        let reportedNetworks = networks
        DispatchQueue.main.async {
            self.completion(sortedPrinters, reportedNetworks, cancelled)
        }
    }

    private static func privatePrefix(_ ip: String) -> String? {
        let parts = ip.split(separator: ".", omittingEmptySubsequences: false).compactMap { Int($0) }
        guard parts.count == 4, parts.allSatisfy({ (0...255).contains($0) }) else { return nil }
        let isPrivate = parts[0] == 10
            || (parts[0] == 172 && (16...31).contains(parts[1]))
            || (parts[0] == 192 && parts[1] == 168)
            || (parts[0] == 169 && parts[1] == 254)
        guard isPrivate else { return nil }
        return "\(parts[0]).\(parts[1]).\(parts[2])"
    }

    private static func ipv4Number(_ ip: String) -> UInt32 {
        return ip.split(separator: ".").compactMap { UInt32($0) }.reduce(0) { ($0 << 8) | $1 }
    }

    private static func localPrivateIPv4Addresses() -> [String] {
        var pointer: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&pointer) == 0, let first = pointer else { return [] }
        defer { freeifaddrs(pointer) }
        var addresses: [String] = []
        var cursor: UnsafeMutablePointer<ifaddrs>? = first
        while let interface = cursor {
            defer { cursor = interface.pointee.ifa_next }
            guard let address = interface.pointee.ifa_addr,
                  Int32(address.pointee.sa_family) == AF_INET else { continue }
            var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            let result = getnameinfo(
                address,
                socklen_t(address.pointee.sa_len),
                &host,
                socklen_t(host.count),
                nil,
                0,
                NI_NUMERICHOST
            )
            guard result == 0 else { continue }
            let ip = String(cString: host)
            if privatePrefix(ip) != nil, !addresses.contains(ip) { addresses.append(ip) }
        }
        return addresses
    }
}

private final class PrinterProbe {
    private let ip: String
    private let port: Int
    private let timeout: TimeInterval
    private var connection: NWConnection?
    private var timeoutWorkItem: DispatchWorkItem?
    private var completion: ((Bool) -> Void)?
    private var finished = false

    init(ip: String, port: Int, timeout: TimeInterval) {
        self.ip = ip
        self.port = port
        self.timeout = timeout
    }

    func start(queue: DispatchQueue, completion: @escaping (Bool) -> Void) {
        self.completion = completion
        guard let endpointPort = NWEndpoint.Port(rawValue: UInt16(port)) else {
            finish(false, notify: true)
            return
        }
        let connection = NWConnection(host: NWEndpoint.Host(ip), port: endpointPort, using: .tcp)
        self.connection = connection
        connection.stateUpdateHandler = { [weak self] state in
            guard let self = self else { return }
            switch state {
            case .ready: self.finish(true, notify: true)
            case .failed, .cancelled: self.finish(false, notify: true)
            default: break
            }
        }
        let timeoutItem = DispatchWorkItem { [weak self] in self?.finish(false, notify: true) }
        timeoutWorkItem = timeoutItem
        queue.asyncAfter(deadline: .now() + timeout, execute: timeoutItem)
        connection.start(queue: queue)
    }

    func cancel() { finish(false, notify: false) }

    private func finish(_ reachable: Bool, notify: Bool) {
        guard !finished else { return }
        finished = true
        timeoutWorkItem?.cancel()
        connection?.stateUpdateHandler = nil
        connection?.cancel()
        connection = nil
        let callback = completion
        completion = nil
        if notify { callback?(reachable) }
    }
}

/** One bounded raw-TCP operation. Network callbacks and timeout state share a serial queue. */
private final class PrinterTCPJob {
    typealias Completion = (Result<Int, Error>) -> Void

    private let target: PrinterTarget
    private let payload: Data?
    private let connectTimeout: TimeInterval
    private let writeTimeout: TimeInterval
    private let completion: Completion
    private let queue = DispatchQueue(label: "mg.labelonzeway.pos80.tcp")
    private var connection: NWConnection?
    private var timeoutWorkItem: DispatchWorkItem?
    private var lastWaitingError: NWError?
    private var finished = false

    init(
        target: PrinterTarget,
        payload: Data?,
        connectTimeout: TimeInterval,
        writeTimeout: TimeInterval,
        completion: @escaping Completion
    ) {
        self.target = target
        self.payload = payload
        self.connectTimeout = connectTimeout
        self.writeTimeout = writeTimeout
        self.completion = completion
    }

    func start() {
        let host = NWEndpoint.Host(target.ip)
        guard let port = NWEndpoint.Port(rawValue: UInt16(target.port)) else {
            finish(.failure(PrinterPluginError.message("Printer port is invalid")))
            return
        }

        let parameters = NWParameters.tcp
        parameters.allowLocalEndpointReuse = true
        let connection = NWConnection(host: host, port: port, using: parameters)
        self.connection = connection
        // NWConnection retains this handler, which intentionally retains the job
        // until finish() clears the handler and breaks the cycle.
        connection.stateUpdateHandler = { state in
            self.handle(state)
        }
        scheduleTimeout(
            after: connectTimeout,
            message: "Connection timed out after \(Int(connectTimeout)) seconds"
        )
        connection.start(queue: queue)
    }

    private func handle(_ state: NWConnection.State) {
        guard !finished else { return }
        switch state {
        case .ready:
            timeoutWorkItem?.cancel()
            if let payload = payload {
                scheduleTimeout(
                    after: writeTimeout,
                    message: "Printer did not accept the job within \(Int(writeTimeout)) seconds"
                )
                send(payload, offset: 0)
            } else {
                finish(.success(0))
            }
        case .waiting(let error):
            // Keep waiting until the bounded connect timeout. This allows a brief
            // Wi-Fi path transition to recover without failing the print job.
            lastWaitingError = error
        case .failed(let error):
            finish(.failure(error))
        case .cancelled:
            if !finished {
                finish(.failure(PrinterPluginError.message("Printer connection was cancelled")))
            }
        default:
            break
        }
    }

    private func send(_ data: Data, offset: Int) {
        guard !finished, let connection = connection else { return }
        if offset >= data.count {
            finish(.success(data.count))
            return
        }

        // Small sequential chunks avoid asking Network.framework or an embedded
        // print server to buffer an entire multi-label job at once.
        let end = min(offset + 64 * 1024, data.count)
        let chunk = data.subdata(in: offset..<end)
        connection.send(
            content: chunk,
            contentContext: .defaultMessage,
            isComplete: end == data.count,
            completion: .contentProcessed { [weak self] error in
                guard let self = self else { return }
                if let error = error {
                    self.finish(.failure(error))
                } else {
                    self.send(data, offset: end)
                }
            }
        )
    }

    private func scheduleTimeout(after seconds: TimeInterval, message: String) {
        timeoutWorkItem?.cancel()
        let workItem = DispatchWorkItem { [weak self] in
            guard let self = self else { return }
            if let waitingError = self.lastWaitingError {
                self.finish(.failure(waitingError))
            } else {
                self.finish(.failure(PrinterPluginError.message(message)))
            }
        }
        timeoutWorkItem = workItem
        queue.asyncAfter(deadline: .now() + seconds, execute: workItem)
    }

    private func finish(_ result: Result<Int, Error>) {
        guard !finished else { return }
        finished = true
        timeoutWorkItem?.cancel()
        connection?.stateUpdateHandler = nil
        connection?.cancel()
        connection = nil
        DispatchQueue.main.async {
            self.completion(result)
        }
    }
}
