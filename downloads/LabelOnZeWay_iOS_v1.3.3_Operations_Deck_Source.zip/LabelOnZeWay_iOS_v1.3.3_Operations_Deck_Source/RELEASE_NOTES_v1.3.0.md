# LabelOnZeWay iOS v1.3.0

Date: 2026-08-15

## Added

- Bounded cancellable automatic POS80C discovery on private local networks.
- Non-destructive **Recover Old Books** with preview/confirmation and conservative merge.
- Direct address-book **Export CSV**.
- Supabase shared-workspace synchronization for authorized business data.
- Forgot Password, Set New Password, and signed-in Change Password flows.

## Retained

- Direct raw-TCP ESC/POS printing and iPhone System Print/AirPrint.
- Zero added feed by default and one partial cut after every physical label copy.
- Complete New Label, Batch, Batch Delete Label, copies 1–20, Manifest, reports, archives, backup, and profile workflows.
- Printer settings and active/deferred queues remain device-local.

## Project metadata

- Bundle ID: `mg.labelonzeway.app`
- Marketing version: `1.3.0`
- Build: `3`
- Minimum iOS: `14.0`
- Capacitor: `7.6.8`

## Validation

- iOS JavaScript workflow suites pass.
- All 46 static project, bridge, discovery, asset, icon, and splash checks pass.
- Capacitor iOS copy/sync completed while preserving custom Swift bridge files.

Mac/Xcode compilation, signing, physical iPhone discovery, AirPrint/POS80C output, and real password-recovery callback validation remain required. No IPA is included because iOS compilation/signing must be completed on macOS with the user's Apple identity/team.
