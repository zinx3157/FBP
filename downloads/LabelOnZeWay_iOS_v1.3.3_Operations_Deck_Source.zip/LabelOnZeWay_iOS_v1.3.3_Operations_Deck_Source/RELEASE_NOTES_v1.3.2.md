# LabelOnZeWay iOS v1.3.2 — Claims Vault & Shared Sync

## Added

- Permanent, versioned electronic copy of every generated label in **Label Claims Vault**.
- Search, preview, and one-copy claim reprint independent of the physical 1–20 copies setting.
- Claim copies survive ordinary Manifest/archive removal, have no automatic expiry, and are included in backup/restore.
- Shared `label_copy` synchronization across LabelOnZeWay and SHIPDESK for authorized staff in the same Supabase workspace/profile.
- Android-parity cloud safety, automatic printer discovery, direct POS80C printing, and system print remain available.

## Upgrade safety

Open the project in Xcode on the Mac and install it over the existing app identity `mg.labelonzeway.app`. Do not delete the installed app first; deleting it removes device-local storage. Export the address book and download a full backup before updating.

Existing Supabase projects must run `SUPABASE_CLAIMS_MIGRATION.sql` (or rerun the full current `SUPABASE_SETUP.sql`) before synchronized claim copies can upload.
