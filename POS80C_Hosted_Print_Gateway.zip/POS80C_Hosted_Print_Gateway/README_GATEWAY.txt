SHIPDESK + LabelOnZeWay v1.3.3 — POS80C HOSTED PRINT GATEWAY
================================================================

PURPOSE
- Lets the public GitHub Pages apps send direct ESC/POS print jobs through this
  computer to a private-network POS80C.
- Supports bounded automatic POS80C discovery on private/local IPv4 networks.
- Includes the v1.3.3 local LabelOnZeWay app with Claims Vault for dependable
  iPhone/iPad direct print when public HTTPS cannot reach an HTTP LAN service.
- Normal browser, AirPrint, Android system print, and iOS system print remain
  available and do not need this gateway.

REQUIREMENTS
- Python 3 on the Mac or Windows PC.
- The computer must reach the POS80C private IP on TCP port 9100.
- For phone use, both devices must be on the same Wi-Fi/LAN and the firewall
  must allow inbound TCP port 8765 on private networks.

FIRST START — macOS
1. Extract this entire ZIP.
2. Double-click Start_Hosted_POS80C_Gateway.command.
3. If macOS blocks it, right-click it and choose Open.
4. Enter the public GitHub username and repository name when prompted.
5. Keep Terminal open while printing.

FIRST START — Windows
1. Extract this entire ZIP.
2. Double-click Start_Hosted_POS80C_Gateway.bat.
3. Allow Python through Windows Firewall for private networks if prompted.
4. Enter the public GitHub username and repository name when prompted.
5. Keep the window open while printing.

APP SETTINGS
- SHIPDESK on this computer: http://127.0.0.1:8765
- Local LabelOnZeWay on a phone: http://COMPUTER_LAN_IP:8765/labelonzeway/
- Hosted LabelOnZeWay gateway URL: http://COMPUTER_LAN_IP:8765/api
- Printer IP: use AUTO-DETECT POS80C or enter the private-network IP
- Printer port: 9100 unless configured differently

IPHONE / IPAD DIRECT PRINT
Safari does not reliably allow a public HTTPS page to call an HTTP LAN service.
Use the local LabelOnZeWay URL shown by the gateway:

  http://COMPUTER_LAN_IP:8765/labelonzeway/

The app automatically uses this gateway. AirPrint remains available from both
public and local copies.

AUTOMATIC DISCOVERY
- Open LabelOnZeWay Settings > Printing and tap AUTO-DETECT POS80C.
- Discovery probes only the selected printer port on no more than four private
  or link-local /24 ranges. It does not scan the public internet.
- Select a discovered printer, save settings, and run TEST CUT.

SECURITY
- Unresolved USERNAME/REPOSITORY placeholders are ignored.
- Hosted requests require the exact configured origin, such as
  https://zinx3157.github.io. There is no *.github.io wildcard.
- Printer targets and discovery are restricted to private, link-local, or
  loopback addresses.
- No GitHub password, Supabase password, or token is requested or stored.

MANUAL START
  python3 hosted_pos80c_gateway.py

Stop with Control-C.
